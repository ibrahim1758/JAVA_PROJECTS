// ---------------------------------------------------------
// Assignment 1
// Written by: Senhaji Ibrahim ; 40316859
// For COMP 248 Section H – Fall 2024
// --------------------------------------------------------

// This program will allow the user to input a sentence longer than 5 charcaters and to get familiar with Java’s String methods.

import java.util.Scanner; // Importing a method that will allow the user to input his values at every messages that will be displayed by the "application".
public class A1_Q2 { // Start of classs

	 public static void main(String[] args) { // Start of main
		// TODO Auto-generated method stub
       System.out.println("Hello! Welcome to my String Inspector program"); // Display the welcome message.
      
      
      
		Scanner keyboard= new Scanner(System.in);// This will allow the user after to input his values, without this statement he will not be able to do so.
		
		String sentence; // Declaring a variable (sentence) type String.
		System.out.print ("Enter the sentence (longer than 5 characters): " ); // Printing out the output for the user to put his sentence (>5 charecters)
		sentence= keyboard.nextLine(); // The user will be allowed here to input his sentence.
		
		
		String word; // Declaring a variable (word) type String.
		System.out.print("Enter the given word: "); // Printing out the output for the user to put his word.
		word=keyboard.nextLine(); // The user will be allowed here to input his word.
		
		
	   String separator; // Declaring a variable (separator) type String.
	   System.out.print("Enter a separator to join the two strings: "); // Printing out the output for the user to put his separator.
	   separator=keyboard.nextLine(); // The user will be allowed here to input his separator.
	   
	   System.out.println();
	   System.out.println();
	   
	   boolean HereOrNot = sentence.contains(word); // Declaring a variable (HereOrNot) type boolean to see if the sentence contains the word that the user inputed by using the sytring method contains().
	   System.out.println("Given sentence contains given word: " + HereOrNot);// The user will be able to validate here if his sentence contains the given word.
	  
	   
	   
	  boolean i= sentence.startsWith("i"); // Declaring a variable (i) type boolean to see if the sentence starts with "i" by using the string method startsWith().
	  System.out.println("Given sentence start with an 'i': " +i);// The user will be to validate here if his sentence starts with i.
	  
	  sentence.replaceAll("a", "e");// This method will replace all the wprds in the sentence that contains the letter a by the letter e.
	  System.out.println("Sentence with 'a' replaced by 'e': " + sentence.replaceAll("a", "e"));// The user will be able to see here if all the words that contains the letter a have been replace by the letter e.
	  
	 String result_sentence= String.join(String.valueOf(separator), sentence, word); // Declaring a variable (result_sentence) type String
	 System.out.println("Joined string: " + result_sentence); // By using the method String.join()
	 
	 sentence.indexOf('a'); // By using the method sentence.indexOf() it will give us the position of the letter a.
	 System.out.println("'a' appears at index " + + sentence.indexOf('a')+ " in the given sentence.");// Here the user will be able to see the answer of the method index.of()
	
	 sentence.charAt(3); // By using the method charAt() it will print us the position at the 3rd position.
	 System.out.println("Character at 3rd position in the given sentence: " + sentence.charAt(3) ); // The user will be able to see the output here for the 3rd position in the sentence.
	
	 System.out.println();
	 System.out.println();
		
	 System.out.print("Thank you for using the String Inspector tool. Have a great day!"); // Displaying the end message.
	
	keyboard.close(); // closing keyboard.
				
	} // End of Main.

}// End of class.
