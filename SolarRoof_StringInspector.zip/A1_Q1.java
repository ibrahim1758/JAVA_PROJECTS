// ---------------------------------------------------------
// Assignment 1
// Written by: Senhaji Ibrahim ; 40316859
// For COMP 248 Section H – Fall 2024
// --------------------------------------------------------

// This program will calculate the daily and annual energy production.
 
import java.util.Scanner; // I am importing a method that will help the user input his values at every messages that will be displayed by the "application".
public class A1_Q1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 Scanner keyboard = new Scanner(System.in); // This will allow the user after to input his values, without this statement he will not be able to do so.
		 System.out.println("Hello welcome to my Solar Roof Energy Calculator program :)"); // Display the welcome message
		 
		 System.out.println();
		
		
		 int numPannels; // Declaring a variable (numPannels) type integer
		 System.out.print ("Enter the number of pannels: " );// Printing out the output for the user to put the number of pannels
		 numPannels= keyboard.nextInt(); // The user will be allowed here to input his value (type integer)
		 
		 
		 int pannelWattage; // Declaring a variable (pannelWattage) type integer
		 System.out.print("Enter the wattage rating of each solar panel (in watts): " ); // Printing out the output for the user to put the number of pannels
		 pannelWattage= keyboard.nextInt(); //  The user will be allowed here to input his value (type integer)
		
		 double sunlightHours; // Declaring a variable (sunlightHours) type double
		 System.out.print("Enter the average number of sunlight hours per day: "); // Printing out the out put for the user the average number of sunlight hours per day
		 sunlightHours= keyboard.nextDouble(); //  The user will be allowed here to input his value (type double)
		
		 double efficiency; // Declaring a variable (efficiency) type double
		 System.out.print("Enter the efficiency of solar panels (as a percentage): "); // Printing out the out put for the user the efficiency in pourcentage.
		 efficiency= keyboard.nextDouble(); // The user will be allowedd here to input his value (type double)
		
		 System.out.println();
	    
		
	     System.out.print("Daily energy production: " + (numPannels*pannelWattage*sunlightHours*efficiency)/(1000*100) + " kwh"); // This is the formula that will calculate the daily energy production thanks to the variables that have been previously declared.
		
	    double Daily; // Declaring a variable (Daily) type double. This will allow us to calculate the annual energy production after.
	    Daily=((numPannels*pannelWattage*sunlightHours*efficiency)/(1000*100) ); // This is the formula that helped us calculate the daily energy production.
	  
	   System.out.println();
	   System.out.println("Annual Energy Production: " + (Daily*365) + " kwh"); // By multiplying the daily energy production by 365 we obtain the annul energy production.
	   System.out.println("Thank you for using the Solar Roof Energy Calculator! See you next time ;)"); // Displaying the end message.
	   
	   
	   keyboard.close(); // Closing the keyboard.
	} //End of main.

} // End of class.
