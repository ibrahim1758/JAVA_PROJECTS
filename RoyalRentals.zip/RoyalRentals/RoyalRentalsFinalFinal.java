package RoyalRentals;
//FINAL DRIVER, ORGANIZATING ALL THE METHODS
// ---------------------------------------------------------
//Assignment 2
//Question: (include question/part number, if applicable) 
//Written by: Ibrahim Senhaji, 40316859
// ---------------------------------------------------------

/*
This program is a rental management system for a fictional company called Royal Rentals, 
which manages vehicles, clients, and leasing operations. 
The program allows users to add, update, delete, and lease vehicles while 
also providing utility functions such as finding the largest truck and copying electric trucks.
 */
public class RoyalRentalsFinalFinal {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
      RoyalRentalsFinal.main(args);// HERE WILL CONTAIN ALL THE METHODS
	}
}
