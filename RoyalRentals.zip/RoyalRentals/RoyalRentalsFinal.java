package RoyalRentals;
import java.util.Scanner;

public class RoyalRentalsFinal { // START OF RRF (Royal Rentals Final)

    public static void main(String[] args) { // START OF MAIN
        Scanner keyboard = new Scanner(System.in);

        boolean programRunning = true;
        while (programRunning) {
            //Display the main menu for Royal Rentals Final
            System.out.println("\n==== ROYAL RENTALS FINAL MENU ====");
            System.out.println("WELCOME TO ROYAL RENTALS WRITTEN BY IBRAHIM SENAJI");   
            System.out.println("1. Run Predefined Scenario");
            System.out.println("2. Access Royal Rentals Menu");
            System.out.println("0. Exit Program");
            System.out.print("Enter your choice: ");

            int choice = keyboard.nextInt();
            keyboard.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    // Run the predefined scenario from RoyalRentals2
                    RoyalRentals2.predefinedScenario();
                    break;
                case 2:
                    //Access the main Royal Rentals menu
                    RoyalRentals.main(args);
                    break;
                case 0:
                    // Exit the program
                    programRunning = false;
                    System.out.println("Exiting program. Goodbye!");
                    return;
                    
                default:
                    //Handle invalid input
                    System.out.println("Invalid choice. Try again.");
            }
        }
        keyboard.close(); // Close scanner to prevent memory leaks
    } // END OF MAIN
} // END OF RRF (Royal Rentals Final)