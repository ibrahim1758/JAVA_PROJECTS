package RoyalRentals;
import Vehicles.*;
import clients.*;
import java.util.Scanner;

public class RoyalRentals {// START OF ROYAL RENTALS

    public static void main(String[] args) {// START OF MAIN
        // Global arrays to store vehicles, clients, and leases
        Vehicle[] vehicles = new Vehicle[0]; 
        Client[] clients = new Client[0]; 
        Lease[] leases = new Lease[0];

        Scanner keyboard = new Scanner(System.in);
        boolean runMenu = true;

        while (runMenu) {
            System.out.println("\n==== ROYAL RENTALS MANAGEMENT ====");
            System.out.println("1. Vehicle Management");
            System.out.println("2. Client Management");
            System.out.println("3. Leasing Operations");
            System.out.println("4. Additional Operations ");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");

            int choice = keyboard.nextInt();
            keyboard.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    // Launch vehicle management system
                    vehicles = VehicleTEst.main(keyboard, vehicles);
                    break;
                case 2:
                    // Launch client management system
                    clients = ClientTest.main(keyboard, clients);
                    break;
                case 3:
                    // Launch leasing operations
                    leases = LeaseTest.main(keyboard, leases, clients, vehicles);
                    break;
                case 4:
                    // Launch additional operations
                    additionalOperations(keyboard, vehicles);
                    break;
                case 0:
                    runMenu = false;
                    System.out.println("Exiting Royal Rentals. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }// END OF MAIN

    // Additional operations menu for specific functionalities
    public static void additionalOperations(Scanner keyboard, Vehicle[] vehicles) {
        boolean runAdditional = true;
        while (runAdditional) {
            System.out.println("    1. Display the truck with the largest capacity");
            System.out.println("    2. Create a copy of the electric trucks array");
            System.out.println("    0. Return to main menu");
            System.out.print("Enter your choice: ");

            int choice = keyboard.nextInt();
            keyboard.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    getLargestTruck(vehicles);
                    break;
                case 2:
                    ET[] electricTrucks = extractElectricTrucks(vehicles);
                    copyVehicles(electricTrucks);
                    break;
                case 0:
                    runAdditional = false;
                    System.out.println("Returning to main menu...");
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    // Find and display the diesel truck with the largest capacity
    public static DT getLargestTruck(Vehicle[] vehicles) {
        if (vehicles.length == 0) {
            System.out.println("No vehicles available.");
            return null;
        }

        DT largestTruck = null;
        double maxCapacity = 0;

        // Iterate through vehicles to find the largest diesel truck
        for (int i = 0; i < vehicles.length; i++) {
            if (vehicles[i] instanceof DT) { // Check if it's a Diesel Truck
                DT truck = (DT) vehicles[i];
                if (truck.getMaxCap() > maxCapacity) {
                    maxCapacity = truck.getMaxCap();
                    largestTruck = truck;
                }
            }
        }

        // Display the largest truck found
        if (largestTruck != null) {
            System.out.println("Diesel Truck with the Largest Capacity:");
            System.out.println(largestTruck.toString());
        } else {
            System.out.println("No diesel trucks found in the vehicle list.");
        }

        return largestTruck; // Return the truck with the largest capacity
    }

    // Create a deep copy of the electric trucks array
    public static ET[] copyVehicles(ET[] electricTrucks) {
        if (electricTrucks.length == 0) {
            System.out.println("No electric trucks available.");
            return new ET[0];
        }

        ET[] electricTrucksCopy = new ET[electricTrucks.length];

        // Copy each electric truck into the new array
        for (int i = 0; i < electricTrucks.length; i++) {
            if (electricTrucks[i] != null) {
                electricTrucksCopy[i] = new ET(
                    electricTrucks[i].getMake(),
                    electricTrucks[i].getModel(),
                    electricTrucks[i].getYOP(),
                    electricTrucks[i].getMaxCap(),
                    electricTrucks[i].getMaxRange()
                );
            }
        }

        System.out.println("A deep copy of the electric trucks array has been created.");
        return electricTrucksCopy;
    }

    // Extract all electric trucks from the vehicle array
    public static ET[] extractElectricTrucks(Vehicle[] vehicles) {
        int count = 0;

        // Count how many electric trucks exist
        for (int i = 0; i < vehicles.length; i++) {
            if (vehicles[i] instanceof ET) {
                count++;
            }
        }

        ET[] electricTrucks = new ET[count];
        int index = 0;

        // Store electric trucks in the new array
        for (int i = 0; i < vehicles.length; i++) {
            if (vehicles[i] instanceof ET) {
                electricTrucks[index] = (ET) vehicles[i];
                index++;
            }
        }
        return electricTrucks;
    }// END OF EXTRACT ELECTRIC TRUCK
}// END OF ROYAL RENTALS