package RoyalRentals;
import Vehicles.*;
import clients.*;

public class RoyalRentals2 {// START OF RR2

    public static void predefinedScenario() {//PREDEFINED SCENARIO 
        System.out.println("\n==== RUNNING PREDEFINED SCENARIO ====\n");

        //Creating objects (3 of each vehicle type)
        // VEHICLE OBJECTS
        Vehicle v1 = new Vehicle("Toyota", "Corolla", 2022);
        Vehicle v2 = new Vehicle("Honda", "Civic", 2023);
        Vehicle v3 = new Vehicle("Nissan", "Altima", 2021);

        // CAR OBJECTS
        Car c1 = new Car("Ford", "Mustang", 2024, 4);
        Car c2 = new Car("BMW", "X5", 2023, 5);
        Car c3 = new Car("Mercedes", "C-Class", 2022, 4);
        
        // TRUCK OBJECTS
        Truck t1 = new Truck("Volvo", "FH16", 2023, 3000);
        Truck t2 = new Truck("Scania", "R500", 2024, 2500);
        Truck t3 = new Truck("Mack", "Anthem", 2022, 2800);
   
        // DT OBJECTS
        DT dt1 = new DT("Kenworth", "T880", 2022, 3500, 500);
        DT dt2 = new DT("Kenworth", "T880", 2022, 3500, 500);
        DT dt3 = new DT("Freightliner", "Cascadia", 2024, 3700, 600);

        // ET OBJECTS
        ET et1 = new ET("Tesla", "Semi", 2023, 2000, 800);
        ET et2 = new ET("Rivian", "R1T", 2024, 1800, 750);
        ET et3 = new ET("Nikola", "Tre", 2023, 2200, 850);

        // GC OBJECTS
        GC gc1 = new GC("Chevrolet", "Camaro", 2022, 4);
        GC gc2 = new GC("Dodge", "Challenger", 2023, 5);
        GC gc3 = new GC("Porsche", "911", 2024, 2);

        // EC OBJECTS
        EC ec1 = new EC("Tesla", "Model S", 2023, 5, 600);
        EC ec2 = new EC("Lucid", "Air", 2024, 5, 700);
        EC ec3 = new EC("Porsche", "Taycan", 2022, 4, 550);

        //  Creating 3 clients
        Client cl1 = new Client("John Doe", 35, "123 Main St", "555-1234");
        Client cl2 = new Client("Jane Smith", 29, "456 Elm St", "555-5678");
        Client cl3 = new Client("Alice Brown", 40, "789 Oak St", "555-9012");

        // Displaying the created objects using toString()
        System.out.println("\n==== VEHICLES ====");
        System.out.println(v1);
        System.out.println(v2);
        System.out.println(v3);
        System.out.println("\n==== CARS ====");
        System.out.println(c1);
        System.out.println(c2);
        System.out.println(c3);
        System.out.println("\n==== TRUCKS ====");
        System.out.println(t1);
        System.out.println(t2);
        System.out.println(t3);
        System.out.println("\n==== DIESEL TRUCKS ====");
        System.out.println(dt1);
        System.out.println(dt2);
        System.out.println(dt3);
        System.out.println("\n==== ELECTRIC TRUCKS ====");
        System.out.println(et1);
        System.out.println(et2);
        System.out.println(et3);
        System.out.println("\n==== GASOLINE CARS ====");
        System.out.println(gc1);
        System.out.println(gc2);
        System.out.println(gc3);
        System.out.println("\n==== ELECTRIC CARS ====");
        System.out.println(ec1);
        System.out.println(ec2);
        System.out.println(ec3);
        System.out.println("\n==== CLIENTS ====");
        System.out.println(cl1);
        System.out.println(cl2);
        System.out.println(cl3);

        //  Testing the equals() method with 3 different cases
        System.out.println("\n==== TESTING EQUALS() ====");
        System.out.println("Comparing objects from different classes: " + v1.equals(c1));
        System.out.println("Comparing objects of the same class but different attributes: " + c1.equals(c2));
        System.out.println("Comparing objects of the same class with identical attributes: " + dt1.equals(new DT("Kenworth", "T880", 2022, 3500, 500)));

        //  Creating arrays for each type of vehicle + a general vehicle array
        Vehicle[] allVehicles = {v1, v2, v3, c1, c2, c3, t1, t2, t3, dt1, dt2, dt3, et1, et2, et3, gc1, gc2, gc3, ec1, ec2, ec3};
        DT[] dieselTrucks = {dt1, dt2, dt3};
        ET[] electricTrucks = {et1, et2, et3};

        //Calling getLargestTruck() with the diesel truck array
        System.out.println("\n==== LARGEST DIESEL TRUCK ====");
        DT largestTruck = RoyalRentals.getLargestTruck(dieselTrucks);
        if (largestTruck != null) {
            System.out.println("🚛 The largest diesel truck is: " + largestTruck);
        }

        //Copying the electric truck array using copyVehicles()
        System.out.println("\n==== COPYING ELECTRIC TRUCKS ====");
        ET[] copiedElectricTrucks = RoyalRentals.copyVehicles(electricTrucks);

        //Verifying that the copy is independent
        copiedElectricTrucks[0].setMake(electricTrucks[0].getMake());
        System.out.println("\nOriginal Electric Truck: " + electricTrucks[0].toString());
        System.out.println("Copied Electric Truck: " + copiedElectricTrucks[0].toString());
    }// END OF PREDEFINED SCENARIP 
}// END OF RR2