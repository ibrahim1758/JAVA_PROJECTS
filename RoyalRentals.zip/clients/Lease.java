package clients;
import Vehicles.*; // Importing the package vehicles here to use the class vehicles in the package clients
public class Lease extends Client {// START OF CLASS LEASE
	private Client[] client;
	private Vehicle [] vehicle;// Attribute of type vehicle to use the method lease vehicles after.
	
	// GETTER
	 public Client[] getClient() {
		return client;
	}
 
	 // SETTER
	public void setClient(Client[] client) {
		this.client = client;
	}

	
 // Constructors 
	 public Lease() {}// Default constructor
	 
	 public Lease(String Name,int age,String Adress, String Phone, Vehicle []vehicle) {// parametrized constructor
		 super(Name,age,Adress,Phone);
		 this.vehicle=vehicle;
	 }
	 
	 public Lease(Lease other) {// Copy Constructor
		 super(other);
		 this.vehicle=other.vehicle;
	 }
	 
 // Accesors
	public Vehicle[] getVehicle() {
		return this.vehicle;
	}

	public void setVehicle(Vehicle [] vehicle) {
		this.vehicle = vehicle;
	}
	@Override
	public String toString() {
	    String result = super.toString() + "\n" + "List of Vehicles Rented " + "from: " + this.getName() + "\n" + "\n";
	    
	    for (int i = 0; i < this.vehicle.length; i++) { 
	        result += this.vehicle[i].toString() + "\n"; // Add vehicle
	    }

	    return result;
	}
	
	@Override 
	public boolean equals(Object obj) {// Equals
		if(obj==null||getClass() != obj.getClass())
			return false;
		 if (this == obj) 
			 return true;
		 
		Lease l=(Lease)obj;
		 return super.equals(obj)&&this.vehicle==l.vehicle;
	}
	
	public void leaseVehicle(Vehicle newVehicle) {
        if (newVehicle == null) {
            System.out.println("Error: Invalid vehicle.");
            return;
        }

        // VERIFY IF VEHICLE ALREADY LEASED
        for (int i = 0; i < this.vehicle.length; i++) {
            if (this.vehicle[i] != null && this.vehicle[i].equals(newVehicle)) {
                System.out.println("This vehicle is already leased.");
                return;
            }
        }

        // ADD VEHICLE TO THE ARRAY
        Vehicle[] updatedVehicles = new Vehicle[this.vehicle.length + 1];
        for (int i = 0; i < this.vehicle.length; i++) {
            updatedVehicles[i] = this.vehicle[i];
        }
        updatedVehicles[this.vehicle.length] = newVehicle;
        this.vehicle = updatedVehicles;

        // PRINTING LEASING CLIENT
        System.out.println("Vehicle successfully leased to " + this.getName());
    }

    // RERTURN VEHICLE
    public void returnVehicle(Vehicle vehicleToReturn) {
        if (vehicleToReturn == null || this.vehicle.length == 0) {
            System.out.println("Error: No vehicle to return.");
            return;
        }

        boolean found = false;
        int count = 0;
        for (int i = 0; i < this.vehicle.length; i++) {
            if (this.vehicle[i] != null && this.vehicle[i].equals(vehicleToReturn)) {
                found = true;
            } else {
                count++;
            }
        }

        if (!found) {
            System.out.println("Vehicle not found in lease records.");
            return;
        }

        // Création d'un nouveau tableau sans le véhicule retourné
        Vehicle[] updatedVehicles = new Vehicle[count];
        int index = 0;
        for (int i = 0; i < this.vehicle.length; i++) {
            if (!this.vehicle[i].equals(vehicleToReturn)) {
                updatedVehicles[index++] = this.vehicle[i];
            }
        }
        this.vehicle = updatedVehicles;
        System.out.println("Vehicle successfully returned.");
    }

    // DISPLAY ALL VEHICLE LEASED BY THIS CLIENT
    public void showClientLeasedVehicles() {
        if (this.vehicle.length == 0) {
            System.out.println("No vehicles leased by " + this.getName());
            return;
        }

        System.out.println("Vehicles leased by " + this.getName() + ":");
        for (int i = 0; i < this.vehicle.length; i++) {
            System.out.println(this.vehicle[i].toString());
        }
    }

    //  DISPLAY ALL THE VEHICLE LEASED
    public static void showAllLeasedVehicles(Lease[] leases) {// LEASE METHOD
        boolean hasLeasedVehicles = false;

        for (int i = 0; i < leases.length; i++) {
            if (leases[i] != null && leases[i].vehicle.length > 0) {
                System.out.println("Client: " + leases[i].getName());
                leases[i].showClientLeasedVehicles();
                hasLeasedVehicles = true;
            }
        }

        if (!hasLeasedVehicles) {
            System.out.println("No vehicles are currently leased.");
        }
    }
}// END OF CLASS LEASE