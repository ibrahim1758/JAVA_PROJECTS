package clients;
import java.util.Scanner;
import Vehicles.*;

public class LeaseTest {

    // Main method for lease operations
    public static Lease[] main(Scanner keyboard, Lease[] leases, Client[] clients, Vehicle[] vehicles) {
        boolean runMenu = true;
        while (runMenu) {
            System.out.println("\n3. Leasing Operations");
            System.out.println("    1. Lease a vehicle to a client");
            System.out.println("    2. Return a vehicle from a client");
            System.out.println("    3. Show all vehicles leased by a client");
            System.out.println("    4. Show all leased vehicles (by all clients)");
            System.out.println("    0. Exit");
            System.out.print("Enter your choice: ");

            int choice = keyboard.nextInt();
            keyboard.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    leases = leaseVehicle(keyboard, leases, clients, vehicles);
                    break;
                case 2:
                    leases = returnVehicle(keyboard, leases);
                    break;
                case 3:
                    showClientLeasedVehicles(keyboard, leases);
                    break;
                case 4:
                    showAllLeasedVehicles(leases);
                    break;
                case 0:
                    runMenu = false;
                    System.out.println("Returning to main menu...");
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
        return leases; // Returns the updated lease list
    }

    // Lease a vehicle to a client
    public static Lease[] leaseVehicle(Scanner keyboard, Lease[] leases, Client[] clients, Vehicle[] vehicles) {
        if (clients.length == 0 || vehicles.length == 0) {
            System.out.println("No clients or vehicles available for leasing.");
            return leases;
        }

        // Select a client
        System.out.println("\nSelect a client:");
        for (int i = 0; i < clients.length; i++) {
            System.out.println((i + 1) + ". " + clients[i].toString());
        }
        System.out.print("Enter client number: ");
        int clientIndex = keyboard.nextInt() - 1;
        keyboard.nextLine();

        if (clientIndex < 0 || clientIndex >= clients.length) {
            System.out.println("Invalid client selection.");
            return leases;
        }
        Client selectedClient = clients[clientIndex];

        // Select a vehicle
        System.out.println("\nSelect a vehicle to lease:");
        for (int i = 0; i < vehicles.length; i++) {
            System.out.println((i + 1) + ". " + vehicles[i].toString());
        }
        System.out.print("Enter vehicle number: ");
        int vehicleIndex = keyboard.nextInt() - 1;
        keyboard.nextLine();

        if (vehicleIndex < 0 || vehicleIndex >= vehicles.length) {
            System.out.println("Invalid vehicle selection.");
            return leases;
        }
        Vehicle selectedVehicle = vehicles[vehicleIndex];

        // Enter lease details
        System.out.print("Enter start date (YYYY-MM-DD): ");
        String startDate = keyboard.nextLine();
        System.out.print("Enter end date (YYYY-MM-DD): ");
        String endDate = keyboard.nextLine();
        System.out.print("Enter price per day: ");
        double pricePerDay = keyboard.nextDouble();
        keyboard.nextLine();

        // Create the lease
        Lease newLease = new Lease(selectedClient.getName(), selectedClient.getAge(), selectedClient.getAdress(), selectedClient.getPhone(), new Vehicle[]{selectedVehicle});
        leases = addLease(leases, newLease);

        System.out.println("Lease successfully created!");
        return leases;
    }

    // Return a vehicle from a client
    public static Lease[] returnVehicle(Scanner keyboard, Lease[] leases) {
        if (leases.length == 0) {
            System.out.println("No active leases available.");
            return leases;
        }

        // Display current leases
        System.out.println("\nSelect a lease to return a vehicle:");
        for (int i = 0; i < leases.length; i++) {
            System.out.println((i + 1) + ". " + leases[i].getName() + " - " + leases[i].getVehicle()[0].getMake() + " " + leases[i].getVehicle()[0].getModel());
        }
        System.out.print("Enter lease number: ");
        int leaseIndex = keyboard.nextInt() - 1;
        keyboard.nextLine();

        if (leaseIndex < 0 || leaseIndex >= leases.length) {
            System.out.println("Invalid selection.");
            return leases;
        }

        // Remove the lease
        leases = deleteLease(leases, leases[leaseIndex]);
        System.out.println("Vehicle successfully returned.");
        return leases;
    }

    // Show all vehicles leased by a specific client
    public static void showClientLeasedVehicles(Scanner keyboard, Lease[] leases) {
        if (leases.length == 0) {
            System.out.println("No leased vehicles.");
            return;
        }

        System.out.print("Enter the client's name: ");
        String clientName = keyboard.nextLine();

        boolean found = false;
        for (int i = 0; i < leases.length; i++) {
            if (leases[i].getName().equalsIgnoreCase(clientName)) {
                leases[i].showClientLeasedVehicles(); // Calls a method from Lease class
                found = true;
            }
        }

        if (!found) {
            System.out.println("No leased vehicles found for this client.");
        }
    }

    // Show all leased vehicles (for all clients)
    public static void showAllLeasedVehicles(Lease[] leases) {
        if (leases.length == 0) {
            System.out.println("No vehicles are currently leased.");
            return;
        }

        System.out.println("\nAll Leased Vehicles:");
        Lease.showAllLeasedVehicles(leases); // Calls a method from Lease class
    }

    // 📌 Utility method to add a lease to the list
    public static Lease[] addLease(Lease[] leases, Lease newLease) {
        Lease[] updatedLeases = new Lease[leases.length + 1];

        // Copy existing leases
        for (int i = 0; i < leases.length; i++) {
            updatedLeases[i] = leases[i];
        }

        // Add the new lease
        updatedLeases[leases.length] = newLease;
        return updatedLeases;
    }

    // Utility method to delete a lease
    public static Lease[] deleteLease(Lease[] leases, Lease leaseToDelete) {
        if (leases.length == 0) {
            return leases;
        }

        // Count how many leases remain after deletion
        int count = 0;
        for (int i = 0; i < leases.length; i++) {
            if (!leases[i].equals(leaseToDelete)) {
                count++;
            }
        }

        // Create a new array without the deleted lease
        Lease[] updatedLeases = new Lease[count];
        int index = 0;

        for (int i = 0; i < leases.length; i++) {
            if (!leases[i].equals(leaseToDelete)) {
                updatedLeases[index++] = leases[i];
            }
        }
        return updatedLeases;
    }
}