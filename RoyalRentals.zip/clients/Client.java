package clients;
public class Client {// START OF CLASS CLIENT
  // Attributes 
	private String Name;
	private int age;
	private String Adress;
	private String Phone;	
  //Constructors
	public Client() {// Default constructor
	}
	
	public Client(String Name,int age,String Adress, String Phone) {// Parametrized constructor
		this.Name=Name;
		this.age=age;
		this.Adress=Adress;
		this.Phone=Phone;
	}
	
	public Client (Client other) {// Copy constructor
		this.Name=other.Name;
		this.Adress=other.Adress;
		this.age=other.age;
		this.Phone=other.Phone;
	}
	
 // Accesors
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getAdress() {
		return Adress;
	}
	public void setAdress(String adress) {
		Adress = adress;
	}
	public String getPhone() {
		return Phone;
	}
	public void setPhone(String phone) {
		Phone = phone;
	}
	
	public boolean equals(Object obj) {// Equals
		if(obj==null||getClass() != obj.getClass())
			return false;
		 if (this == obj) 
			 return true;
		 
		 Client c=(Client)obj;
		 return this.Name.equals(c.Name)&&
				this.Adress.equals(c.Adress)&&
				this.age==c.age&&
				this.Phone==c.Phone;
	}
	
	public String toString() {// To string
		return "\n"+"Name: "+this.Name+"\n"+
	            "Adress: "+this.Adress+"\n"+
				"Age: "+this.age+"\n"+
	            "Phone Number: "+this.Phone;
	}
	
	public static Client[] AddClient(Client[] c, Client... newClients) {// STATIC ADD CLIEMT; static to acces it in the main. Using Syntax ... to pass infinite Clientss.
		 if (c== null || c.length == 0) {
		        return newClients; // If the array v is empty it will return the new clients.
		    }		 
		 //Create a bigger array (old + new vehicles)
		  Client[] updatedClients = new Client[c.length + newClients.length];

		    // Old Clients
		    for (int i = 0; i < c.length; i++) {
		        updatedClients[i] = c[i];
		    }
		    //Add new vehicles 
		    for (int i = 0; i < newClients.length; i++) {
		        updatedClients[c.length + i] = newClients[i];
		    }
		    return updatedClients; // Return the new Array

	} 
	
	public static Client[]EditClient(Client[] c, Client... clientsToUpdate) {// START OF EDIT CLIENT
	    if (c == null || c.length == 0 || clientsToUpdate.length % 2 != 0) {
	        return c; // RETURN THE ORIGINAL ARRAY
	    }

	    for (int i = 0; i < c.length; i++) {
	        for (int j = 0; j < clientsToUpdate.length; j += 2) { // GO THROUGH THE PAIRS 
	            if (c[i].equals(clientsToUpdate[j])) { // CHECK IF VEHICLE 
	                c[i] = clientsToUpdate[j + 1]; // REPLACE NEW VEHICLE 
	                break;
	            }
	        }
	    }

	    return  c; // RETURN THE NEW ARRAY 
	}// END OF EDIT CLIENT 
	
	public static Client[] DeleteClient(Client[] c, Client... clientsToDelete) {// DELETE METHOD
		  if (c == null || c.length == 0) {
		        return new Client[0]; // RETURN THE EMPTY ARRAY
		    }
		  
		  int count = 0;
		    for (int i = 0; i < c.length; i++) {
		        boolean shouldDelete = false;
		        for (Client toDelete :clientsToDelete) {// ENHANCED LOOP TO GO THROUGH THE CLIENT TO DELETE 
		            if (c[i] != null && c[i].equals(toDelete)) {
		                shouldDelete = true;
		                break;
		            }
		        }
		        if (!shouldDelete) {
		            count++;
		        }
		    }

		  // CREATE ARRAY TO STOCK THE ARRAY OF REMAINING VEHICLES 
		   Client[] updatedClients = new Client[count];
		    int index = 0;

		    // COYING REMAINING VEHICLES
		    for (int i = 0; i < c.length; i++) {
		        boolean shouldDelete = false;
		        for (Client toDelete : clientsToDelete) {// ENHANCED LOOP TO GO THROUGH THE CLIENT TO DELETE 
		            if (c[i] != null && c[i].equals(toDelete)) {
		                shouldDelete = true;
		                break;
		            }
		        }
		        if (!shouldDelete) {
		            updatedClients[index++] = c[i];
		        }
		    }
		    return updatedClients;

	}// ENd of delete
}// END OF CLASS CLIENT

