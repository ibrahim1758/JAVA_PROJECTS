package clients;
import java.util.Scanner;
public class ClientTest {// START OF CLIENT TEST
	public static Client[] main(Scanner keyboard, Client[] clients) {// START OF MAIN
        boolean runMenu = true;
        while (runMenu) {// START OF WHILE MENU
            System.out.println("\n2. Client Management");
            System.out.println("    1. Add A Client");
            System.out.println("    2. Edit A Client");
            System.out.println("    3. Delete A Client");
            System.out.println("    4. Show All Clients");
            System.out.println("    0. Exit");
            System.out.print("Enter your choice: ");

            int choice = keyboard.nextInt();
            keyboard.nextLine(); // CLEAN BUFFER

            switch (choice) {// SWITCH CHOOSE
                case 1:
                    clients = add(keyboard, clients);// FOR ADD
                    break;
                case 2:
                    clients = edit(keyboard, clients);// FOR EDIT
                    break;
                case 3:
                    clients = delete(keyboard, clients);// FOR DELETE
                    break;
               
                case 0:
                    runMenu = false;
                    System.out.println("Returning to main menu...");
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }// END OF SWITCH
        }
        return clients; // RETURN CLIENTS
    }// END OF MAIN
	
	public static Client[] add (Scanner keyboard ,Client[]c) {//ADD CLIENT
		
		boolean displayWhile2 = true;
	    while (displayWhile2) {// WHILE FOR DISPLAY 
	        System.out.print("Would you like to add a client? (Yes/No) ");
	        String answer = keyboard.nextLine();
	        if (answer.equalsIgnoreCase("yes")) {
	            // ASKING USER INFO ON CLIENTS
	            System.out.print("Enter the client's name: ");
	            String Name = keyboard.nextLine();

	            System.out.print("Enter the client's age: ");
	            int age = keyboard.nextInt();
	            keyboard.nextLine(); // CLEANING BUFFER
	            
                System.out.print("Enter the client's adress: ");
	            String adress = keyboard.nextLine();
	            
	            System.out.print("Enter the client's phone number: ");
	            String phoneNumber = keyboard.nextLine();
	            // CREATING CLIENT OBJECT
	            Client newClient = new Client(Name,age,adress,phoneNumber);

	            // ADDING CLIENT USING ADD METHOD
	            c = Client.AddClient(c, newClient);

	            System.out.println("NEW CLIENT HAS BEEN ADDED!");
	        } 
	        else if (answer.equalsIgnoreCase("no")) {
	            displayWhile2 = false;
	            System.out.println("Returning to main menu...");
	        } 
	        else {
	            System.out.println("Invalid input. Please enter Yes or No.");
	        }
	    }

	    return c;
	}// END ADD CLIENT 
	
	
	
	public static Client[] edit(Scanner keyboard, Client[] c) {// Start of edit 
	    if (c == null || c.length == 0) {
	        System.out.println("No clients available to edit.");
	        return c; // RETURN THE ORIGINAL ARRAY IF EMPTY 
	    }

	    boolean editing = true;
	    while (editing) {
	        // DISPLAYING EXISTING CLIENTS 
	        System.out.println("Here are the available clients:");
	        for (int i = 0; i < c.length; i++) {
	            System.out.println((i + 1) + ". " + c[i].toString());
	        }

	        System.out.print("Enter the number of the client you want to edit (or 0 to exit): ");
	        int clientIndex = keyboard.nextInt();
	        keyboard.nextLine(); // CLEANING BUFFER

	        if (clientIndex == 0) {
	            editing = false;
	            System.out.println("Returning to main menu...");
	            continue;
	        }

	        if (clientIndex < 1 || clientIndex > c.length) {
	            System.out.println("Invalid choice. Try again.");
	            continue;
	        }

	        Client clientToEdit = c[clientIndex - 1]; // TAKING AVAILABLE CLIENTS 

	        System.out.println("Editing client: " + clientToEdit.toString());
	        boolean updating = true;

	        while (updating) {// WHILE UPDATE
	            System.out.println("Which attribute would you like to edit?");
	            System.out.println("1. Name");
	            System.out.println("2. Age");
	            System.out.println("3. Adress");
	            System.out.println("4. Phone number");
	            System.out.println("0. Finish editing this client");

	            System.out.print("Enter your choice: ");
	            int editChoice = keyboard.nextInt();
	            keyboard.nextLine(); //CLEANING BUFFER

	            switch (editChoice) {// START OF SWITCH EDIT CLIENT
	            // CLIENT WILL CHOOSE BASE ON TTHE NUMBER
	                case 1:
	                    System.out.print("Enter new name: ");
	                    clientToEdit.setName(keyboard.nextLine());
	                    break;
	            
	                case 2:
	                    System.out.print("Enter new age: ");
	                    clientToEdit.setAge(keyboard.nextInt());
	                    keyboard.nextLine();
	                    break;
	                case 3:
	                    System.out.print("Enter new Adress: ");
	                    clientToEdit.setAdress(keyboard.nextLine());
	                    break;
	                case 4:
	                    System.out.print("Enter new phone number: ");
	                    clientToEdit.setPhone(keyboard.nextLine());
	                    break;
	                    
	                case 0:
	                    updating = false;
	                    System.out.println("Client updated successfully!");
	                    break;
	                default:
	                    System.out.println("Invalid choice. Try again.");
	            }// END OF SWITCH
	        }// END OF WHILE UPDATE 
	    }// end of switch editing
	    
	    return c; // RETURN ARRAY
	}// END EDIT CLIENT
	
	public static Client[] delete(Scanner keyboard, Client[] c) {// DELETE
	    if (c == null || c.length == 0) {
	        System.out.println("No clients available to delete.");
	        return c; // RETURNING THE EMPTY ARRAY
	    }

	    boolean deleting = true;
	    while (deleting) {
	        // DISPLAYING THE EXISTING CLIENTS 
	        System.out.println("Here are the available clients:");
	        
	        // DISPLAYING THE AVAILABLE CLIENTS
	        for (int i = 0; i < c.length; i++) {
	            System.out.println((i + 1) + ". " + c[i].toString());
	        }
	        
	        // NUMBER FOR DELETE CLIENT 
	        System.out.print("Enter the number of the client you want to delete (or 0 to exit): ");
	        int clientIndex = keyboard.nextInt();
	        keyboard.nextLine(); // CLEAN THE BUFFER

	        if (clientIndex == 0) {// PRESSING 0 TO EXIT 
	            deleting = false;
	            System.out.println("Returning to main menu...");
	            continue;
	        }

	        if (clientIndex < 1 || clientIndex > c.length) {// FOR THE INVALID CHOICE 
	            System.out.println("Invalid choice. Try again.");
	            continue;
	        }
	        
	        Client clientToDelete = c[clientIndex - 1]; // TAKE THE CLIENT 
	        System.out.println("Deleting client: " + clientToDelete.toString());// PRINTING CLIENT DELETED 

	        // DELETING CLIENT USING THE DELETECLIENT() 
	        c = Client.DeleteClient(c, clientToDelete);
	        System.out.println("Client successfully deleted!");
	        System.out.print("Would you like to delete another client? (Yes/No): ");
	        String answer = keyboard.nextLine();// USER ENTERS ANSWER 
	        
	        if (!answer.equalsIgnoreCase("yes")) {
	            deleting = false;
	            System.out.println("Returning to main menu...");
	        }
	        
	    }// END OF WHILE DELETING	    
	    return c; // RETURNING THE FINAL ANSWER 
	}// END OF DELETE
}// END OF CLASS TEST