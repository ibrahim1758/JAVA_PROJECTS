package Vehicles;
public class Truck extends Vehicle {// Start of Truck 
	private double MaxCap;// Attribute of Truck
	private static int tCounter = 0;

	public Truck () {}// Default Contructor
			
	public Truck(String Make, String Model, int YOP,double MaxCap) {// Calling the super constructor as well as setting the attribute
		super(Make,Model,YOP);
		this.MaxCap=MaxCap;
		this.vehicleNumber= ++tCounter;
	}
			
     public Truck(Truck truck) {// Copy Constructor for the attribute
		    super(truck);
			this.MaxCap=truck.MaxCap;
			this.vehicleNumber= ++tCounter;
	}
			
	public double getMaxCap() {
				return this.MaxCap;
	}

	public void setMaxCap(double maxCap) {
				this.MaxCap = maxCap;
	}
	
	public static void resetTruckCounter() { tCounter = 0; }
	
	@Override
	public String toString(boolean showVehicleID) {
		 return (showVehicleID ? "Truck "+ this.vehicleNumber +"\n": "")  +
		super.toString(false)+"Max Capacity :"+this.MaxCap+" Kg"+"\n";// So the vehicle will not get displayed
	}
	@Override 
	public boolean equals(Object obj) {
	if (obj == null || getClass() != obj.getClass()) 
	    return false;
				  
	 if (this == obj) return true;
		Truck t=(Truck)obj;
	   return super.equals(obj)&&this.MaxCap==t.MaxCap;
	}
}// End of truck

