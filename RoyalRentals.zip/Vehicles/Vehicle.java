package Vehicles;
public class Vehicle {// Creating Class Parent Vehicle for the package Vehicles which is the first package.
	// Since the plate number will be assigned automatically I will declare it in the child classes.
	private String plateNumber;
	private String Make;// Make
	private String Model;// Model
	private int YOP;//Year of prod
	private static int counter=1;// counyter
    protected int vehicleNumber; //vehicleCounter
	private static int vehicleCounter = 0; 
	
	// Default constructor to initialize all the attributes to their default values.
	public Vehicle() {}
	
// Parametrized Constructor 
	public Vehicle(String Make, String Model, int YOP) {
	this.Make = Make;
	this.Model = Model;
	this.YOP = YOP;
	this.plateNumber = plateNumber;
	this.vehicleNumber = ++vehicleCounter;
}
	
	public String getPlateNumber() {
        return plateNumber;
    }

    public void setPlateNumber(String plateNumber) {
        this.plateNumber = plateNumber;
    }

//Copy Constructor with one parameter type Vehicle
	 /*It duplicates the values of the fields from one object to another, creating a separate,
    independent object with the same state as the original. Basically it creates a new object with the same state as the original one
	    */
	
	public Vehicle (Vehicle vehicle) {
		this.Make = vehicle.Make;
		this.Model = vehicle.Model;
		this.YOP = vehicle.YOP;
	}
	
	
// Getters And Setters for all attributes of the class Vehicle 
	public String getMake() {
		return this.Make;
	}
	
	public void setMake(String Make) {
		this.Make = Make;
	}
	
	public String getModel() {
		return this.Model;
	}
	
	public void setModel(String Model) {
		this.Model = Model;
	}
	
	public int getYOP() {
		return this.YOP;
	}
	
	public void setYOP(int YOP) {
		this.YOP = YOP;
	}
	
/*Equals Method.It will compare the calling object to another object. 
	It should: Return false if the passed object is null or of a different class type. 
		And Compare all attributes except for the plate number and return true if the objects are 
		equal.
*/
	
  public boolean equals(Object obj) {// Equals Method
	  if (obj == null || getClass() != obj.getClass()) 
		  return false;
	  
	  if (this == obj) return true;
	  
	 Vehicle vehicle = (Vehicle) obj;
	 return Make.equals(vehicle.Make)&&
			 YOP==(vehicle.YOP)&&
			 Model.equals(vehicle.Model);
  }
  
  
  
  // toStr Method
  public String toString(boolean showVehicleID) { 
      return (showVehicleID ? "Vehicle " + this.vehicleNumber + "\n" : "") + // Display the id only if showVehicleID == true
             "Make: " + this.Make + "\n" +
             "Model: " + this.Model + "\n" +
             "Year Of Production: " + this.YOP + "\n";
  }
  
//toStr Method
  public String toString1() { 
      return "Vehicle " + this.vehicleNumber +  ":"  +"\n"+ // Display the id only if showVehicleID == true
             "Make: " + this.Make + "\n" +
             "Model: " + this.Model + "\n" +
             "Year Of Production: " + this.YOP + "\n";
  }
  
   @Override
  public String toString() {
      return toString(true); // By default the vehicle "Vehicle Y " gets displayes
  }
   
   public static Vehicle[] AddVehicle(Vehicle[] v, Vehicle... newVehicles) { // STATIC ADD VEHICLE; static to acces it in the main. Using Syntax ... to pass infinite Vehicles.
	    if (v == null || v.length == 0) {
	        return newVehicles; // If the array v is empty it will return the new vehicles.
	    }

	    //Create a bigger array (old + new vehicles)
	    Vehicle[] updatedVehicles = new Vehicle[v.length + newVehicles.length];

	    // Old Vehicles
	    for (int i = 0; i < v.length; i++) {
	        updatedVehicles[i] = v[i];
	    }
	    //Add new vehicles 
	    for (int i = 0; i < newVehicles.length; i++) {
	        updatedVehicles[v.length + i] = newVehicles[i];
	    }
	    
	  //Attributes to reset the counter after adding
	  int ecCounter = 1001, gcCounter = 1001, dtCounter = 1001, etCounter = 1001;
	    for (int i = 0; i < updatedVehicles.length; i++) {
	        if (updatedVehicles[i] != null) {
	        	 if (updatedVehicles[i] instanceof EC) {
	                updatedVehicles[i].setPlateNumber("EC" + ecCounter++);
	                
	            } else if (updatedVehicles[i] instanceof GC) {
	                updatedVehicles[i].setPlateNumber("GC" + gcCounter++);
	            } 
	            else if (updatedVehicles[i] instanceof DT) {
	                updatedVehicles[i].setPlateNumber("DT" + dtCounter++);
	            } else if (updatedVehicles[i] instanceof ET) {
	                updatedVehicles[i].setPlateNumber("ET" + etCounter++);
	            }
	        }
	    }

	    return updatedVehicles; // Return the new Array
   }// End of Add VEhicle
   
   public static Vehicle[] DeleteVehicle(Vehicle[] v, Vehicle... vehiclesToDelete) {// STATIC DELETE VEHICLE; static to acces it in the main. Using Syntax ... to pass infinite Vehicles.
	   if (v == null || v.length == 0) {
	        return new Vehicle[0]; //Return an emty array
	    }

	    // Vehicles remaining after the delete 
	    int count = 0;
	    for (int i = 0; i < v.length; i++) {
	        boolean shouldDelete = false;
	        for (Vehicle toDelete : vehiclesToDelete) {
	            if (v[i] != null && v[i].equals(toDelete)) {
	                shouldDelete = true;
	                break;
	            }
	        }
	        if (!shouldDelete) {
	            count++;
	        }
	    }

	    // Array for remaining vehicles 
	    Vehicle[] updatedVehicles = new Vehicle[count];
	    int index = 0;

	    // copying the last vehicles with enhanced loop
	    for (int i = 0; i < v.length; i++) {
	        boolean shouldDelete = false;
	        for (Vehicle toDelete : vehiclesToDelete) {
	            if (v[i] != null && v[i].equals(toDelete)) {
	                shouldDelete = true;
	                break;
	            }
	        }
	        if (!shouldDelete) {
	            updatedVehicles[index++] = v[i];
	        }
	    }

	   
	    // Attributes to reassign the plates 
	    int ecCounter = 1001, gcCounter = 1001, dtCounter = 1001, etCounter = 1001;

	    for (int i = 0; i < updatedVehicles.length; i++) {
	        if (updatedVehicles[i] != null) {
	        	 if (updatedVehicles[i] instanceof EC) {
	                updatedVehicles[i].setPlateNumber("EC" + ecCounter++);
	            } else if (updatedVehicles[i] instanceof GC) {
	                updatedVehicles[i].setPlateNumber("GC" + gcCounter++);
	            } 
	            else if (updatedVehicles[i] instanceof DT) {
	                updatedVehicles[i].setPlateNumber("DT" + dtCounter++);
	            } else if (updatedVehicles[i] instanceof ET) {
	                updatedVehicles[i].setPlateNumber("ET" + etCounter++);
	            }
	        }
	    }

	    return updatedVehicles;// return the last array
	}
   
   

public static Vehicle[] UpdateVehicle(Vehicle[] v, Vehicle... vehiclesToUpdate) {// STATIC METHOD TO UPDATE
	    if (v == null || v.length == 0 || vehiclesToUpdate.length % 2 != 0) {
	        return v; // RETURN V
	    }

	    for (int i = 0; i < v.length; i++) {
	        for (int j = 0; j < vehiclesToUpdate.length; j += 2) { // GOES THROUGH THE PAIRS (OLD/NEW)
	            if (v[i].equals(vehiclesToUpdate[j])) { // VERIFY IF THERE IS SOMETHING TO MODIFY 
	                v[i] = vehiclesToUpdate[j + 1]; // REPLAACE BY THE NEW VEHICLE
	                break;
	            }
	        }
	    }

	    return  v; // RETURN THE UPDATED ARRAY 
	}// eND OF THE METHOD TO UPDATE
  
   public static void ListVehiclesByCategory(Vehicle[] vehicles) {// LIST VEHICLE
	    //Check if the array is null or empty
	    if (vehicles == null || vehicles.length == 0) {
	        System.out.println("Cannot display vehicles: The list is empty.");
	        return;
	    }

	    //Display header
	    System.out.println("List of Vehicles by Category:");

	    //Loop for normal Vehicles (exactly Vehicle class)
	    resetCounter();
	    System.out.println("\n--- Vehicles ---");
	    for (int i = 0; i < vehicles.length; i++) {
	        if (vehicles[i] != null && vehicles[i].getClass() == Vehicle.class) {
	        	resetCounter();
	        	 System.out.println(vehicles[i].toString());
	        }
	    }

	    //Loop for Trucks (exactly Truck class)
	    Truck.resetTruckCounter();
	    System.out.println("\n--- Trucks ---");
	    for (int i = 0; i < vehicles.length; i++) {
	        if (vehicles[i] != null && vehicles[i] instanceof Truck && vehicles[i].getClass() == Truck.class) {
	        	vehicles[i].vehicleNumber = counter++; // Réaffectation des numéros
	            System.out.println(vehicles[i].toString());
	        }
	    }

	    //Loop for Cars (exactly Car class)
	   Car.resetCarCounter();
	    System.out.println("\n--- Cars ---");
	    int carNumber = 1;
	    for (int i = 0; i < vehicles.length; i++) {
	        if (vehicles[i] != null && vehicles[i] instanceof Car && vehicles[i].getClass() == Car.class) {
	            vehicles[i].vehicleNumber = carNumber++; // Réaffectation des numéros
	            System.out.println(vehicles[i].toString());
	        }
	    }

	    //Loop for Diesel Trucks (DT)
	    resetCounter();
	    System.out.println("\n--- Diesel Trucks (DT) ---");
	    for (int i = 0; i < vehicles.length; i++) {
	        if (vehicles[i] != null && vehicles[i] instanceof DT) {
	        	resetCounter();
	        	 System.out.println(vehicles[i].toString());
	        }
	    }

	    //Loop for Electric Trucks (ET)
	    resetCounter();
	    System.out.println("\n--- Electric Trucks (ET) ---");
	    for (int i = 0; i < vehicles.length; i++) {
	        if (vehicles[i] != null && vehicles[i] instanceof ET) {
	        	resetCounter();
	        	 System.out.println(vehicles[i].toString());
	        }
	    }

	    //Loop for Gasoline Cars (GC)
	    resetCounter();	    
	    System.out.println("\n--- Gasoline Cars (GC) ---");
	    for (int i = 0; i < vehicles.length; i++) {
	    	
	        if (vehicles[i] != null && vehicles[i] instanceof GC) {
	        	resetCounter();
	            System.out.println(vehicles[i].toString());
	        }
	    }

	    //Loop for Electric Cars (EC)
	    resetCounter();
	    System.out.println("\n--- Electric Cars (EC) ---");
	    
	    for (int i = 0; i < vehicles.length; i++) {
	        if (vehicles[i] != null && vehicles[i] instanceof EC) {
	        	EC.resetCounter();
	        	 System.out.println(vehicles[i].toString());
	            
	        }
	    }
	}

   public static void resetCounter() {
	   counter=1;
	   
	}//END OF LIST VEHICLE
}// END OF CLASS VEHICLE

