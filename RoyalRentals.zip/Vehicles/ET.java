package Vehicles;
public class ET extends Truck{
	 //ET STANDS FOR ELECTICK TRUCKS
	 private double MaxRange;
	 private String plateNumber;// Not in the constructor its automatic;
	 private static int counter = 1001;
	 private static int etCounter = 0;
	 
	public ET() {// Default constructor
	}
	
	public ET(String Make, String Model, int YOP, double MaxCap ,double MaxRange) {
		super(Make,Model,YOP,MaxCap);
		this.MaxRange=MaxRange;
		this.plateNumber = "ET" + counter++;// to increment
		this.vehicleNumber= ++etCounter;
	}
	
	public ET(ET other) {// Copy Constructor
		super(other);
		this.MaxRange=other.MaxRange;
	}
	public double getMaxRange() {//Getter
		return MaxRange;
	}
	public void setMaxRange(double maxRange) {//Getter
		MaxRange = maxRange;
	}
	public String getPlateNumber() {//Getter
		return plateNumber;
	}
	public void setPlateNumber(String plateNumber) {//Getter
		this.plateNumber = plateNumber;
	}
	@Override
	public String toString() {// To String
		return  "Electric truck "+this.vehicleNumber+ "\n"+
				super.toString(false)+"Maximum Range: "+this.MaxRange+ " Km"+"\n"+"Plate Number: "+this.plateNumber+"\n";
	}
	
	@Override
	public boolean equals(Object obj) {// Equals 
		if (obj == null || getClass() != obj.getClass()) 
			  return false;
		if (this == obj) return true;
		
		ET e=(ET)obj;
		return super.equals(obj)&&this.MaxRange==e.MaxRange;
	} 
}// END OF CLASS ET
