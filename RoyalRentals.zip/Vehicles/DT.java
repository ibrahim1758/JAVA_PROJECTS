package Vehicles;
public class DT extends Truck{// START OF CLASS DT
	 // DT STANDS FOR DIESEL TRUCK, DT will increment
	 private double fuelCap;
	 private String plateNumber;
	
	 private static int counter = 1001;// For the plate
	 private static int dtCounter = 0;
	 
	 public DT() {// Default Constructor
		 
	 }
	 
	public DT(String Make, String Model, int YOP,double MaxCap, double fuelCap) {// Parametrized Constructor
		super( Make, Model, YOP,MaxCap);
		this.fuelCap=fuelCap;
		 this.plateNumber = "DT" + counter++;
		 this.vehicleNumber =++dtCounter;
	}
	
	public DT(DT other) {// Copy constructor
		super(other);
		this.fuelCap=other.fuelCap;
		 this.vehicleNumber =++dtCounter;
	}
	public double getFuelCap() {// Getter
		return fuelCap;
	}
	
	public String getPlate() {
		return this.plateNumber;
	}
	
	public void setPlateNumber(String PlateNumber) {
		this.plateNumber=PlateNumber;
	}

	public void setFuelCap(double fuelCap) {// Setter
		this.fuelCap = fuelCap;
	}
	
	@Override
	public String toString() {
		return "Diesel Truck "+ this.vehicleNumber +"\n"+
				super.toString(false)+"Fuel Capacity: "+this.fuelCap+ "L"+"\n"+"Plate Number :"+this.plateNumber+"\n";
	}
	
	@Override
	public boolean equals(Object obj) {
		if (obj == null || getClass() != obj.getClass()) 
			  return false;
		if (this == obj) return true;
		  
		DT dt=(DT)obj;
		return super.equals(obj)&&this.fuelCap==dt.fuelCap;
	}
	
	
}// END OF CLASS DT