package Vehicles;
import java.util.Scanner;
public class VehicleTEst {// START OF VEHICLE TEST
	public static Vehicle[] main(Scanner keyboard, Vehicle[] vehicles) {// START OF MAIN
		
        boolean runMenu = true;// VARIABLE FOR THE WHILE LOOP OF THE MENU 
        while (runMenu) {// START OF THE MAIN WHILE
         // DISPLAY THE MENU       	
            System.out.println("    1. Add A Vehicle");
            System.out.println("    2. Delete A Vehicle");
            System.out.println("    3. Update vehicle information");
            System.out.println("    4. List all vehicles by category");
            System.out.println("    0. Exit");
            System.out.print("Enter your choice: ");

            int choice = keyboard.nextInt();// THE UER WILL ENTER HIS CHOICE
            keyboard.nextLine(); // CLEANING THE BUFFER 
            
            switch (choice) {// START OF CHOICE 
                case 1:// CHOICE FOR ADD
                    vehicles = add(keyboard, vehicles);
                    break;
                case 2:// CHOICE FOR DELETE
                    vehicles = delete(keyboard, vehicles);
                    break;
                case 3:// CHOICE FOR UPDATE
                    vehicles = update(keyboard, vehicles);
                    break;
                case 4:// CHOICE FOR LIST
                    list(keyboard,vehicles);
                    break;
                case 0:// CHOICE FOR EXIT
                    runMenu = false;
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
        return vehicles; // RETURN THE UPDATED LIST
    }


	
	public static Vehicle[] list(Scanner keyboard, Vehicle[] v) {// START OF LIST
	    Vehicle.resetCounter();
	    Vehicle.ListVehiclesByCategory(v);
	    return v;
	}// END OF LIST
	
	public static Vehicle[] update(Scanner keyboard, Vehicle[] v) {// START OF UPDATE
	    boolean displayWhile2 = true;
	    while (displayWhile2) {// START OF THE WHILE LOOP 
	        System.out.println("List of Available Vehicles:");
	        Vehicle.resetCounter();
	        Vehicle.ListVehiclesByCategory(v);

	        System.out.print("Would you like to update a Vehicle? ");// ASKING THE USER IF UPDATE 
	        String answer = keyboard.nextLine();

	        if (answer.equalsIgnoreCase("yes")) {
	            System.out.println("What type of vehicle would you like to update?");
	            System.out.println("(Vehicle, Car, Truck, Electric Truck, Diesel Truck, Electric Car, Gasoline Car)");
	            String vehicleType = keyboard.nextLine().toLowerCase();

	            // VERIFICATION THE VEHICLE TYPE
	            String className = "";
	            switch (vehicleType) {// SWITCH FOR TYPE
	                case "gasoline car": className = "GC"; break;
	                case "electric car": className = "EC"; break;
	                case "electric truck": className = "ET"; break;
	                case "diesel truck": className = "DT"; break;
	                case "car": className = "Car"; break;
	                case "truck": className = "Truck"; break;
	                case "vehicle": className = "Vehicle"; break;
	                default:
	                    System.out.println("Invalid vehicle type.");
	                    continue;
	            }// END SWITCH FOR TYPE

	            //DISPLAY THE VEHICLES AVAILABLE BASED ON CHOICE
	            System.out.println("Here are the available " + vehicleType + "s:");
	            Vehicle.resetCounter();
	            int counter = 1;
	            boolean found = false;
	            int[] indexMapping = new int[v.length]; // STOCK REAL INDEX

	            for (int i = 0; i < v.length; i++) {
	                if (v[i] != null && v[i].getClass().getSimpleName().equals(className)) {
	                    System.out.println(counter + ". " + v[i].toString());
	                    indexMapping[counter - 1] = i; // STOCK REAL INDEX 
	                    found = true;
	                    counter++;
	                }
	            }

	            if (!found) {// IF NOT FOUND = NO VEHICLE
	                System.out.println("No " + vehicleType + "s found.");
	                continue;
	            }

	           // VEHICLE TO UPDATE
	            System.out.print("Enter the number of the " + vehicleType + " you want to update: ");
	            int vehicleNumber = keyboard.nextInt();// USER WILL ENTER VALUE HERE
	            keyboard.nextLine();

	            if (vehicleNumber < 1 || vehicleNumber >= counter) {
	                System.out.println("Invalid number. Returning to main menu...");
	                continue;
	            }

	            int realIndex = indexMapping[vehicleNumber - 1]; // Récupération de l'index réel
	            Vehicle vehicleToUpdate = v[realIndex];

	            boolean updateChoice = true;
	            while (updateChoice) {// WHILE LOOP FOR ATT
	                // DISPLAYING THE ATTRIBUTES 
	                if (vehicleToUpdate instanceof DT) { 
	                    System.out.println("Attributes available: (make/model/year/maxCapacity/fuelCapacity)");
	                } else if (vehicleToUpdate instanceof ET) { 
	                    System.out.println("Attributes available: (make/model/year/maxCapacity/maxRange)");
	                } else if (vehicleToUpdate instanceof EC) { 
	                    System.out.println("Attributes available: (make/model/year/maxPassengers/maxRange)");
	                } else if (vehicleToUpdate instanceof GC) {  
	                    System.out.println("Attributes available: (make/model/year/maxPassengers)");
	                } else if (vehicleToUpdate instanceof Truck) { 
	                    System.out.println("Attributes available: (make/model/year/maxCapacity)");
	                } else if (vehicleToUpdate instanceof Car) { 
	                    System.out.println("Attributes available: (make/model/year/maxPassengers)");
	                } else { 
	                    System.out.println("Attributes available: (make/model/year)");
	                }

	                System.out.print("Which attribute do you want to update? ");
	                String attributeToUpdate = keyboard.nextLine();

	                switch (attributeToUpdate.toLowerCase()) {
	                    case "make":
	                        System.out.print("Enter new Make: ");
	                        vehicleToUpdate.setMake(keyboard.nextLine());
	                        break;
	                    case "model":
	                        System.out.print("Enter new Model: ");
	                        vehicleToUpdate.setModel(keyboard.nextLine());
	                        break;
	                    case "year":
	                        System.out.print("Enter new Year: ");
	                        vehicleToUpdate.setYOP(keyboard.nextInt());
	                        keyboard.nextLine();
	                        break;
	                    case "max capacity":
	                        if (vehicleToUpdate instanceof Truck || vehicleToUpdate instanceof DT || vehicleToUpdate instanceof ET) {
	                            System.out.print("Enter new Max Capacity: ");
	                            double newMaxCap = keyboard.nextDouble();
	                            keyboard.nextLine();
	                            if (vehicleToUpdate instanceof Truck) {
	                                ((Truck) vehicleToUpdate).setMaxCap(newMaxCap);
	                            } else if (vehicleToUpdate instanceof DT) {
	                                ((DT) vehicleToUpdate).setMaxCap(newMaxCap);
	                            } else {
	                                ((ET) vehicleToUpdate).setMaxCap(newMaxCap);
	                            }
	                        } else {
	                            System.out.println("Invalid attribute for this vehicle type.");
	                        }
	                        break;
	                    case "max passengers":
	                        if (vehicleToUpdate instanceof Car || vehicleToUpdate instanceof EC || vehicleToUpdate instanceof GC) {
	                            System.out.print("Enter new Maximum Passengers: ");
	                            int newPassengers = keyboard.nextInt();
	                            keyboard.nextLine();
	                            if (vehicleToUpdate instanceof Car) {
	                                ((Car) vehicleToUpdate).setMaxPass(newPassengers);
	                            } else if (vehicleToUpdate instanceof EC) {
	                                ((EC) vehicleToUpdate).setMaxPass(newPassengers);
	                            } else {
	                                ((GC) vehicleToUpdate).setMaxPass(newPassengers);
	                            }
	                        } else {
	                            System.out.println("Invalid attribute for this vehicle type.");
	                        }
	                        break;
	                    case "max range":
	                        if (vehicleToUpdate instanceof ET || vehicleToUpdate instanceof EC) {
	                            System.out.print("Enter new Max Range: ");
	                            double newMaxRange = keyboard.nextDouble();
	                            keyboard.nextLine();
	                            if (vehicleToUpdate instanceof ET) {
	                                ((ET) vehicleToUpdate).setMaxRange(newMaxRange);
	                            } else {
	                                ((EC) vehicleToUpdate).setMaxRange(newMaxRange);
	                            }
	                        } else {
	                            System.out.println("Invalid attribute for this vehicle type.");
	                        }
	                        break;
	                    case "fuel capacity":
	                        if (vehicleToUpdate instanceof DT) {
	                            System.out.print("Enter new Fuel Capacity: ");
	                            double newFuelCap = keyboard.nextDouble();
	                            keyboard.nextLine();
	                            ((DT) vehicleToUpdate).setFuelCap(newFuelCap);
	                        } else {
	                            System.out.println("Invalid attribute for this vehicle type.");
	                        }
	                        break;
	                    default:
	                        System.out.println("Invalid attribute choice.");
	                        break;
	                }

	                Vehicle.resetCounter();
	                System.out.print("Do you want to update another attribute? (yes/no): ");
	                String continueUpdating = keyboard.nextLine();
	                if (continueUpdating.equalsIgnoreCase("no")) {
	                    updateChoice = false;
	                }
	            }// END OF WHILE

	            v[realIndex] = vehicleToUpdate;
	            System.out.println(vehicleType.toUpperCase() + " HAS BEEN UPDATED!");

	        } else if (answer.equalsIgnoreCase("no")) {
	            displayWhile2 = false;
	            System.out.println("Returning to main menu...");
	        }
	    }
	    return v;// RETURN THE ARRAY
	}// END OF UPDATE

	public static Vehicle[] delete(Scanner keyboard, Vehicle[] v) {// DELETE METHOD 
	    boolean displayWhile2 = true;
	    while (displayWhile2) {// START OF WHILE FO DELETE 
	        System.out.print("Would you like to delete a vehicle? (Yes/No) ");
	        String answer = keyboard.nextLine();
	        Vehicle.resetCounter();

	        if (answer.equalsIgnoreCase("yes")) {// CHCECKING IF THERE ARE VEHICLES AVAILABLE TO DEL
	            if (v == null || v.length == 0 || v[0] == null) {
	                System.out.println("No vehicles were entered yet. Cannot delete a vehicle.");
	                System.out.println("Returning to main menu...");
	                displayWhile2 = false;
	            } 
	            else {
	                Vehicle.resetCounter();
	                Vehicle.ListVehiclesByCategory(v);
	                System.out.print("What Vehicle would you like to delete? ");
	                String choiceOfVehicle = keyboard.nextLine().toLowerCase();  //CONVERTS TO LOWER CASE

	                // ADAPTING THE CLASSES IN THE FONCTION OF NAME
	                String className = "";
	                switch (choiceOfVehicle) {// SWITCH FOR CONVERTS 
	                // CONVERTING THE TYPES 
	                    case "gasoline car": className = "GC"; break;
	                    case "electric car": className = "EC"; break;
	                    case "electric truck": className = "ET"; break;
	                    case "diesel truck": className = "DT"; break;
	                    case "car": className = "Car"; break;
	                    case "truck": className = "Truck"; break;
	                    case "vehicle": className = "Vehicle"; break;
	                    default:
	                        System.out.println("Invalid vehicle type.");
	                        continue;
	                }// END OF SWITCH FOR CONVERTS 

	                System.out.println("Here are the available " + choiceOfVehicle + "s:");// DISPLAYING BASED ON CHOICE 
	                Vehicle.resetCounter();
	                boolean found = false;
	                int displayedIndex = 1;
	                int[] indexMapping = new int[v.length];

	                for (int i = 0; i < v.length; i++) {
	                    if (v[i] != null && v[i].getClass().getSimpleName().equalsIgnoreCase(className)) {
	                        System.out.println(displayedIndex + ". " + v[i].toString());
	                        indexMapping[displayedIndex - 1] = i;
	                        found = true;
	                        displayedIndex++;
	                    }
	                }

	                if (!found) {
	                    System.out.println("No " + choiceOfVehicle.toUpperCase() + "s found.");
	                    continue;
	                }

	                System.out.print("Enter the number of the " + choiceOfVehicle + " you want to delete: ");
	                int userChoice = keyboard.nextInt();
	                keyboard.nextLine();
	                if (userChoice < 1 || userChoice >= displayedIndex) {
	                    System.out.println("Invalid number. Returning to main menu...");
	                    continue;
	                }
	                int realIndex = indexMapping[userChoice - 1];
	                v = Vehicle.DeleteVehicle(v, v[realIndex]);// CALLING THE DELETE VEHICLE FROM VEHICLE 	              
	                System.out.println(choiceOfVehicle.toUpperCase() + " HAS BEEN DELETED!");
	                displayedIndex = 1;
	                for (int i = 0; i < v.length; i++) {
	                    if (v[i] != null && v[i].getClass().getSimpleName().equalsIgnoreCase(className)) {
	                        v[i].vehicleNumber = displayedIndex; //UPDATING THE NUMBER OF VEHICLE
	                        displayedIndex++;
	                    }
	                }
	                
	         }// END OF IF FOR DELETING
	        } // END OF IF OF YES
	        
	        else if (answer.equalsIgnoreCase("no")) {
	            displayWhile2 = false;
	            System.out.println("Returning to main menu...");
	        }
	        
	    }// END OF WHILE DELETE
	    return v;
	}// END OF DELETE


	public static Vehicle[] add(Scanner keyboard, Vehicle[] v) {// ADD METHOD

	    boolean displayWhile2 = true;
	    while (displayWhile2) {// START OF WHILE 
	        System.out.print("Would you like to add a vehicle? (Yes/No) ");
	        String answer = keyboard.nextLine();
	        
	        if (answer.equalsIgnoreCase("yes")) {// IF FOR YES ADD
	            System.out.println("What Vehicle would you like to add? ");
	            System.out.print("Vehicle, Car, Truck, Electric Truck, Diesel Truck, Electric Car, Gasoline Car: ");
	            String choiceOfVehicle = keyboard.nextLine();

	            switch (choiceOfVehicle.toUpperCase()) {// SWITCH FOR TYPE ADDING
	                case "VEHICLE":
	                    System.out.print("Please enter a Make: ");
	                    String make = keyboard.nextLine();
	                    System.out.print("Please enter a Model: ");
	                    String model = keyboard.nextLine();
	                    System.out.print("Please enter a year: ");
	                    int year = keyboard.nextInt();
	                    keyboard.nextLine();
	                    
	                    int nextVehiculeNumber = 1;
	                    for (int i = 0; i < v.length; i++) {
	                        if (v[i] instanceof Vehicle) {
	                            nextVehiculeNumber++;
	                        }
	                    }	                  
	                    Vehicle newVehicle = new Vehicle(make, model, year);
	                    newVehicle.vehicleNumber=nextVehiculeNumber;
	                    v = Vehicle.AddVehicle(v, newVehicle);// ADDING VEHICLE USING ADDVEHICLE METHOD
	                    System.out.println("NEW VEHICLE HAS BEEN ADDED !");
	                    break;

	                case "CAR":            
	                	System.out.print("Please enter a Make for Car: ");
	                    String carMake = keyboard.nextLine();
	                    System.out.print("Please enter a Model for Car: ");
	                    String carModel = keyboard.nextLine();
	                    System.out.print("Please enter a year for Car: ");
	                    int carYear = keyboard.nextInt();
	                    System.out.print("Please enter a Maximum of Passengers: ");
	                    int maxPass = keyboard.nextInt();
	                    keyboard.nextLine();
	                    
	                    int nextCarNumber = 1;
	                    for (int i = 0; i < v.length; i++) {
	                        if (v[i] instanceof Car) {
	                            nextCarNumber++;
	                        }
	                    }
	                    
	                    Car newCar = new Car(carMake, carModel, carYear, maxPass);
	                   newCar.vehicleNumber = nextCarNumber; 
	                    v = Vehicle.AddVehicle(v, newCar); // ADDING VEHICLE USING ADDVEHICLE METHOD	                   
	                    System.out.println("NEW CAR HAS BEEN ADDED !");
	                    
	                    break;

	                case "TRUCK":
	                    System.out.print("Please enter a Make for Truck: ");
	                    String truckMake = keyboard.nextLine();
	                    System.out.print("Please enter a Model for Truck: ");
	                    String truckModel = keyboard.nextLine();
	                    System.out.print("Please enter a year for Truck: ");
	                    int truckYear = keyboard.nextInt();
	                    System.out.print("Please enter a Max Capacity: ");
	                    double maxCap = keyboard.nextDouble();
	                    keyboard.nextLine();
	                    int nextTruckNumber = 1;
	                    for (int i = 0; i < v.length; i++) {
	                        if (v[i] instanceof Truck) {
	                            nextTruckNumber++;
	                        }
	                    }

                        //Truck.resetTruckCounter();
	                    Truck newTruck = new Truck(truckMake, truckModel, truckYear, maxCap);
	                    newTruck.vehicleNumber=nextTruckNumber;
	                    v = Vehicle.AddVehicle(v, newTruck);// ADDING VEHICLE USING ADDVEHICLE METHOD
	                   
	                    System.out.println("NEW TRUCK HAS BEEN ADDED !");
	                    //Vehicle.resetCounter(); // Reset counter here
	                    break;

	                case "ELECTRIC TRUCK":
	                    System.out.print("Please enter a Make for Electric Truck: ");
	                    String etMake = keyboard.nextLine();
	                    System.out.print("Please enter a Model for Electric Truck: ");
	                    String etModel = keyboard.nextLine();
	                    System.out.print("Please enter a year for Electric Truck: ");
	                    int etYear = keyboard.nextInt();
	                    System.out.print("Please enter a Max Capacity: ");
	                    double etMaxCap = keyboard.nextDouble();
	                    System.out.print("Please enter a Max Range: ");
	                    double etMaxRange = keyboard.nextDouble();
	                    keyboard.nextLine();
	                    
	                    int nextETNumber = 1;
	                    for (int i = 0; i < v.length; i++) {
	                        if (v[i] instanceof ET) {
	                            nextETNumber++;
	                        }
	                    }

 
	                    ET newET = new ET(etMake, etModel, etYear, etMaxCap, etMaxRange);
	                    newET.vehicleNumber = nextETNumber;
	                    v = Vehicle.AddVehicle(v, newET);// ADDING VEHICLE USING ADDVEHICLE METHOD
	                    System.out.println("NEW ELECTRIC TRUCK HAS BEEN ADDED !");	                    
	                    break;

	                case "DIESEL TRUCK":
	                    System.out.print("Please enter a Make for Diesel Truck: ");
	                    String dtMake = keyboard.nextLine();
	                    System.out.print("Please enter a Model for Diesel Truck: ");
	                    String dtModel = keyboard.nextLine();
	                    System.out.print("Please enter a year for Diesel Truck: ");
	                    int dtYear = keyboard.nextInt();
	                    System.out.print("Please enter a Max Capacity: ");
	                    double dtMaxCap = keyboard.nextDouble();
	                    System.out.print("Please enter a Fuel Capacity: ");
	                    double fuelCap = keyboard.nextDouble();
	                    keyboard.nextLine();
	                    
	                    int nextDTNumber = 1;
	                    for (int i = 0; i < v.length; i++) {
	                        if (v[i] instanceof DT) {
	                            nextDTNumber++;
	                        }
	                    }

	                    DT newDT = new DT(dtMake, dtModel, dtYear, dtMaxCap, fuelCap);
	                    newDT.vehicleNumber = nextDTNumber;
	                    v = Vehicle.AddVehicle(v, newDT);// ADDING VEHICLE USING ADDVEHICLE METHOD
	                    System.out.println("NEW DIESEL TRUCK HAS BEEN ADDED !");
	                    break;

	                case "ELECTRIC CAR":
	                    System.out.print("Please enter a Make for Electric Car: ");
	                    String ecMake = keyboard.nextLine();
	                    System.out.print("Please enter a Model for Electric Car: ");
	                    String ecModel = keyboard.nextLine();
	                    System.out.print("Please enter a year for Electric Car: ");
	                    int ecYear = keyboard.nextInt();
	                    System.out.print("Please enter a Maximum of Passengers: ");
	                    int ecMaxPass = keyboard.nextInt();
	                    System.out.print("Please enter a Max Range: ");
	                    double ecMaxRange = keyboard.nextDouble();
	                    keyboard.nextLine();

	                    int nextECNumber = 1;
	                    for (int i = 0; i < v.length; i++) {
	                        if (v[i] instanceof EC) {
	                            nextECNumber++;
	                        }
	                    }
	                    
	                    
	                    EC newEC = new EC(ecMake, ecModel, ecYear, ecMaxPass, ecMaxRange);
	                    newEC.vehicleNumber = nextECNumber;
	                    v = Vehicle.AddVehicle(v, newEC);// ADDING VEHICLE USING ADDVEHICLE METHOD
	                    System.out.println("NEW ELECTRIC CAR HAS BEEN ADDED !");
	                    break;

	                case "GASOLINE CAR":
	                    System.out.print("Please enter a Make for Gasoline Car: ");
	                    String gcMake = keyboard.nextLine();
	                    System.out.print("Please enter a Model for Gasoline Car: ");
	                    String gcModel = keyboard.nextLine();
	                    System.out.print("Please enter a year for Gasoline Car: ");
	                    int gcYear = keyboard.nextInt();
	                    System.out.print("Please enter a Maximum of Passengers: ");
	                    int gcMaxPass = keyboard.nextInt();
	                    keyboard.nextLine();
	                    
	                   int nextGCNumber=1;
	                    for (int i = 0; i < v.length; i++) {
	                        if (v[i] instanceof GC) {
	                            nextGCNumber++;
	                        }
	                    }
	                    
	                    GC newGC = new GC(gcMake, gcModel, gcYear, gcMaxPass);
	                    newGC.vehicleNumber = nextGCNumber;
	                    v = Vehicle.AddVehicle(v, newGC);// ADDING VEHICLE USING ADDVEHICLE METHOD
	                    System.out.println("NEW GASOLINE CAR HAS BEEN ADDED !");
	                    break;

	                default:
	                    System.out.println("Invalid vehicle choice.");
	                    break;
	                    
	            }// END OF SWITCH ADDING
	        }// END OF IF YES ADDING 
	        
	        else if (answer.equalsIgnoreCase("no")) {// START OF IF ADDING
	            displayWhile2 = false;
	            System.out.println("Returning to main menu...");
	        }// END OF IF NO ADDING
	    }// END OF WHILE	   
	    return v;// RETURNING THE ARRAY
	}// END OF ADD METHOD
}	