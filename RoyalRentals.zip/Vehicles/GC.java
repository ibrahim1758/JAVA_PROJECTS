package Vehicles;

public class GC extends Car{
	// GC STANDS FOR GASOLINE CARS
	 //private static int count=1;//For the toStr method
	 private static int counter = 1001;
	 private String plateNumber;// Not in constructor. Set Automatically
	 private static int gcCounter = 0;
	 public GC(){// DEFAULT CONSTRUCTOR
		 
	 }
	 
	 public GC(String Make, String Model, int YOP,int MaxPass) { // Parametrized Constructor;
		 super(Make,Model,YOP,MaxPass);
		 this.plateNumber="GC"+ counter++;// to increment
		 this.vehicleNumber=++gcCounter;
	}

	public GC(GC other) {// Copy Constructor
		super(other);
	}
	public String getPlateNumber() {
		return plateNumber;
	}

	public void setPlateNumber(String plateNumber) {
		this.plateNumber = plateNumber;
	}
	
	@Override 
	public String toString() {
		return "Gasoline Car " + this.vehicleNumber + "\n"
	            + super.toString(false) 
	            + "Plate Number: " + this.plateNumber + "\n"; 
	}
	
	 
	@Override 
	public boolean equals(Object obj) {
		if (obj == null || getClass() != obj.getClass()) 
			  return false;
		if (this == obj) return true;
		return super.equals(obj);
	}	 
}// END OF CLASS GC
