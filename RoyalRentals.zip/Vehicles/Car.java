package Vehicles;
public class Car extends Vehicle {
    private int MaxPass; // Attribute for class Car
    private static int carCounter = 0; // Counter for Car class

    public Car() { // Default Constructor
    }

    public Car(String Make, String Model, int YOP, int MaxPass) { // Parametrized Constructor
        super(Make, Model, YOP);
        this.MaxPass = MaxPass;
        this.vehicleNumber = ++carCounter; // Increment Car counter
    }
    public static void resetCarCounter() {carCounter = 0; }
    
    public Car(Car car) { // Copy Constructor of Class Car
        super(car);
        this.MaxPass = car.MaxPass;
        this.vehicleNumber = ++carCounter; // Increment Car counter
    }

    public int getMaxPass() { // Getter
        return this.MaxPass;
    }

    public void setMaxPass(int maxPass) { // Setter
        this.MaxPass = maxPass;
    }
    
    public String toString1() { 
    	//Car.resetCounter();
        return  "Car " + this.vehicleNumber+ "\n"+ ": " +
                super.toString(false) + "Maximum Passengers:" + this.MaxPass + "\n"; // So the vehicle will not get displayed
    }
   
     @Override
    public String toString() {
    	 //Car.resetCounter();
        return toString(true); // By default the vehicle "Vehicle Y " gets displayes
    }

    @Override
    public String toString(boolean showVehicleIDcar) {
        return (showVehicleIDcar ? "Car " + this.vehicleNumber + "\n" : "") +
                super.toString(false) + "Maximum Passengers:" + this.MaxPass + "\n";
    }

    @Override
    public boolean equals(Object obj) { // Equals Method
        if (obj == null || getClass() != obj.getClass())
            return false;
        if (this == obj) return true;

        Car c = (Car) obj;
        return super.equals(obj) && this.MaxPass == c.MaxPass;
    }
}