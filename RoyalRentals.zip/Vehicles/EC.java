package Vehicles;
public class EC extends Car{
	 //EC STANDS FOR ELECTRIC CARS
	 //private static int count=1;// toStr method
	 private double MaxRange;
	 //private static int counter = 1001;
	 private static int ecCounter = 0;
	 private String plateNumber;// Not in constructor. Set Automatically
	 

   public EC() {// Default Constructor
			 
		 } 
   public void setPlateNumber(String newPlate) {
	    this.plateNumber = newPlate;
	}
   
   public void setEcCounter(String newEcCounter) {
	    this.plateNumber = newEcCounter;
	}
	 
	 public EC(String Make, String Model, int YOP,int MaxPass,double MaxRange) {//Parametrized constructort
		 super(Make,Model,YOP,MaxPass);
		 this.MaxRange=MaxRange;
		 this.plateNumber="EC"+(1001 + ecCounter++); 
		 this.vehicleNumber= ecCounter;
	 }
	 
	 public EC(EC other) {// Copy Constructor
		 super(other);
		 this.vehicleNumber = ecCounter;
		 this.MaxRange=other.MaxRange;
	 }

	public double getMaxRange() {
		return MaxRange;
	}

	public void setMaxRange(double maxRange) {
		MaxRange = maxRange;
	}
	
	 public String getPlateNumber() {
		return plateNumber;
	}
	 /*public static void resetCounter() {
		    counter = 1001;  // Réinitialiser le compteur de plaques
		    // Réinitialiser le numéro des véhicules électriques
		}*/

	@Override
	public String toString() {
		return  "Electric Car "+ this.vehicleNumber+ "\n"+
				super.toString(false)+"Maximum Range: "+this.MaxRange+ " Km"+"\n"+"Plate Number :"+this.plateNumber+"\n";
	} 
	
	@Override 
	public boolean equals(Object obj) {
		if (obj == null || getClass() != obj.getClass()) 
			  return false;
		if (this == obj) return true;
		
		EC ec=(EC)obj;
		return super.equals(obj)&& this.MaxRange==ec.MaxRange;
	}	 
}// END OD CLASS EC
