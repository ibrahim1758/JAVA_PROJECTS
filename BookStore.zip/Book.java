// ---------------------------------------------------------
// Assignment 0
// Question: (include question/part number, if applicable) 
// Written by: Senhaji Ibrahim ; 40316859
// ---------------------------------------------------------

public class Book {//Start of class book
	
// 4 attributes declared in private to not violate encapsulation 
	private String title;
	private String author;
	private long ISBN;
	private double price;
	private int numberOfBooks;
	
// Default Constructor. To set all the attributes to their default values.
	public Book() {}

// Copy Constructor with one parameter Book other 
	/*It duplicates the values of the fields from one object to another, creating a separate,
    independent object with the same state as the original. Basically it creates a new object with the same state as the original one
    */
	public Book(Book other) {
		this.title=other.title;
		this.author=other.author;
		this.ISBN=other.ISBN;
		this.price=other.price;
		this.numberOfBooks=other.numberOfBooks;
	}

// Getters and setters for all attributes 
  // Since the attributes are private we must use getters. They are methods that let you access the values of private attributes in a class.
	// Getter for title
	public String getTitle() {
		return this.title;
	}
	
	// getter for strings
	public String getAuthor() {
		return this.author;
	}
	
	// getter for isbn
	public long getIsbn() {
		return this.ISBN;
	}
	
	//getter for price
	public double getPrice() {
		return this.price;
	}
	
	// getter for number
	public int getNumber() {
		return this.numberOfBooks;
	}
	
 // Setters are methods that allow you to change the values of private attributes in a class. I have the total control of them.
	// setter for title
	public void setTitle(String title) {
		this.title=title;
	}
	// setter for author
	public void setAuthor(String author) {
		this.author=author;
	}
	// setter for isbn
	public void setISBN(long ISBN) {
		this.ISBN=ISBN;
	}
	// setter for price
	public void setPrice(double price) {
		this.price=price;
	}
	// setter for number
	public void setNumber(int numberOfBooks) {
		this.numberOfBooks=numberOfBooks;
	}
	
// Method  findNumberOfCreatedBooks()
	public int findNumberOfCreatedBooks() {
        if (this.numberOfBooks == 0) {
            return 0;
        }
        return this.numberOfBooks;
    }
	
	
 // Equals method 
	public boolean equals(Book other) {
		return ISBN==other.ISBN && 
			   price==other.price;
	}

// To string method
	public String toString() {
		
		return "Title :"+this.title+"\n"+
				"Author :"+this.author+"\n"+
				"ISBN : "+this.ISBN+"\n"+
				"Price : "+this.price+"$";
		
	}
}// End of class book
