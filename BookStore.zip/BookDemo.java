import java.util.Scanner;//Importing a class from java.util that will allow the user after to enter his values
/*
 In this program the user will be able to modify the data of his oe her bookstore. To do so
 a menu will be displayed where the user will be able to enter new books, edits its information, display
 all the books under a specific author and display all the books under a specific price.
 */
public class BookDemo {// Start of class
   public static void main(String[] args) {// Start of Main
		// TODO Auto-generated method stub
Scanner keyboard=new Scanner(System.in);// For the input
//Welcome the user
  System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
  System.out.println("       Welcome to Montreal BookStore Application developped by Ibrahim Senhaji");
  System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
  System.out.println();
  
/*Prompt the bookstore owner for the maximum number of books (maxBooks) his/her 
  bookstore can contain. Create an empty array, called inventory, that will have the potential 
  of keeping track of the created Book objects. */
  int book;// Declaring a variable type int named book
  System.out.print("Please enter the maximum of books your bookstore can contain : ");
  book=keyboard.nextInt();// The user will enter the MaxBooks
  Book[] inventory=new Book[book];// creating the array of books
  int currentBooks = 0; // Tracks the number of books currently in the inventory

  
//Displaying the menu for the user 
  System.out.println("What do you want to do ?");
  System.out.println("   1. Enter new books (password required) ");
  System.out.println("   2. Change information of a book (password required)");
  System.out.println("   3. Display all books by a specific author ");
  System.out.println("   4. Display all books under a certain a price.");
  System.out.println("   5. Quit ");
  System.out.print("Please enter your choice > ");
  int choice=keyboard.nextInt();// The useer will enter his choice here 
  
  
  int totalFailedAttempts = 0;
  final int MAX_FAILED_ATTEMPTS = 12;// Constant
  final int PASSWORD =249;// Constant
  
  
  while(choice>=0) {
	  switch(choice) {//Start of switch
	  
	  // Choice for quitting
	  case 5:
	     System.out.print("Thank you for using Montreal Montreal BookStore Application!");
	     return;// So it goes out of the while completely.
	  
	  // Choice for new books 
	  case 1:
		  boolean passwordVerified = false;
          for (int attempt = 0; attempt < 3; attempt++) {// Loop for 3 tries 
              System.out.print("Enter your password: ");
              int password = keyboard.nextInt();// Usser will enter the password

              if (password == PASSWORD) {
                  passwordVerified = true;
                  System.out.println("Password correct! Access granted.");
                  break;// It exists out of the loop
              } 
              
              else {
                  System.out.println("Incorrect password, please try again!");
              }
          }// End of loop 

          if (!passwordVerified) {
              totalFailedAttempts += 3;
              System.out.println("Returning to the main menu due to multiple incorrect attempts.");
          
              // Terminate the program if total failed attempts reach the limit
              if (totalFailedAttempts >= MAX_FAILED_ATTEMPTS) {
                  System.out.println("Program detected suspicious activities and will terminate immediately!");
                  return;
              }
              break; // Return to the main menu
          }
	    

          // Ask the owner how many books they want to enter
          System.out.print("How many books do you want to enter? ");
          int numBooksToAdd = keyboard.nextInt();

          // Check if there is enough space in the bookstore
          if (currentBooks + numBooksToAdd <= book) {
              for (int i = 0; i < numBooksToAdd; i++) {// Creating new books
                  System.out.println("Enter details for book " + (currentBooks + 1) + ":");
                  keyboard.nextLine();
                  System.out.print("Title: ");
                  String title = keyboard.nextLine();// USer will enter title 
                  System.out.print("Author: ");
                  String author = keyboard.nextLine();//USer will enter auth
                  System.out.print("ISBN: ");
                  long isbn = keyboard.nextLong();//USer will enter isbn
                  System.out.print("Price: ");
                  double price = keyboard.nextDouble();// USer will enter price

                  
                  // Here is the use of the setters 
                  inventory[currentBooks] = new Book();
                  inventory[currentBooks].setTitle(title);
                  inventory[currentBooks].setAuthor(author);
                  inventory[currentBooks].setISBN(isbn);
                  inventory[currentBooks].setPrice(price);
                  currentBooks++;// Incrementing each book a new book is added
              }
              System.out.println(numBooksToAdd + " book(s) successfully added to the inventory.");
          } 
          
          else {
              System.out.println("Not enough space in the bookstore. You can only add " + (book - currentBooks) + " more book(s). Returning to the main menu.");
          }
          break;
        
	  case 2:
		 // Same thing as case 1 except it's slightly different
		 passwordVerified = false;

          for (int attempt = 0; attempt < 3; attempt++) {// Start of for
              System.out.print("Enter your password: ");
              int password = keyboard.nextInt();

              if (password == PASSWORD) {
                  passwordVerified = true;
                  System.out.println("Password correct! Access granted.");
                  break;// It exists out of the loop
              } else {
                  System.out.println("Incorrect password, please try again!");
              }
          }// End of for

          if (!passwordVerified) { // Will check if it respects the conditon for case 1
              totalFailedAttempts += 3;
              System.out.println("Returning to the main menu due to multiple incorrect attempts.");
          }
          
          
          
          System.out.print("What book would you like to update ? ");
          int Book =keyboard.nextInt();// User will enter his value here 
          if (Book < 1 || Book > inventory.length || inventory[Book - 1] == null) {// Condition for the arrays 
              System.out.println("Error: Book "+Book+" not found! Returning to the main menu.");
              break; // Returning to the main menu if not found
          }
          System.out.println();
          System.out.println(inventory[Book-1].toString());
          
          
          // For Information 
          boolean update=true; // Declaring a variable boolean named update 
          while (update) {// Start of while loop for case 2
        	// For Information 
              System.out.println("What information would you like to change ?");
              System.out.println("       1.Author");
              System.out.println("       2.Title");
              System.out.println("       3.ISBN");
              System.out.println("       4.Price");
              System.out.println("       5.Quit");
              System.out.print("Please enter your choice > ");
              int info_book=keyboard.nextInt();// USer will enter his choice here
        	  switch(info_book) {// Start of switch for case 2
        	  
        	  case 1:// Author
        		  System.out.print("Enter the new name for the Author: ");
        		  keyboard.nextLine();
                  String author = keyboard.nextLine();
                  inventory[Book-1].setAuthor(author);
                  System.out.println("The new author has been set");
                  break;// Exiting the switch
                  
                  
        	  case 2:// Title
        		  System.out.print("Enter the new name for the Title: ");
        		  keyboard.nextLine();
                  String title = keyboard.nextLine();
                  inventory[Book-1].setTitle(title);
                  System.out.println("The new title has been set");
                  break;// Exiting the switch
                  
        	  case 3://ISBN
        		  System.out.print("Enter the new ISBN: ");
                  long ISBN = keyboard.nextLong();
                  inventory[Book-1].setISBN(ISBN);
                  System.out.println("The new ISBN has been set");
                  break;// Exiting the switch
                  
        	  case 4://Price
        		  System.out.print("Enter the new Price: ");
                  double price = keyboard.nextDouble();
                  inventory[Book-1].setPrice(price);
                  System.out.println("The new price has been set");
                  break;// Exiting the switch
                  
        	  case 5://Quit
        		  update=false;// quiting here
        		  System.out.println("Exiting the menu. Returning to the main menu !");
        		  break;// Exiting the switch
        		  
              
        	  default:// if the useer enters an invalid input
              System.out.println("Invalid choice please try again"); 
        	  System.out.println("What information would you like to change ?");
              System.out.println("       1.Author");
              System.out.println("       2.Title");
              System.out.println("       3.ISBN");
              System.out.println("       4.Price");
              System.out.println("       5.Quit");
              System.out.print("Please enter your choice > ");
              info_book=keyboard.nextInt();
        	  }// End of switch for case 2
        	 
          }// End of while loop for case 2
          break;// Exiting the switch
          
      // Choice for author  
	  case 3:
		  System.out.print("Please enter an author's name: ");
		  keyboard.nextLine();
		  String author=keyboard.nextLine();
		  boolean found =false;
		  for (int i=0;i<currentBooks;i++) {
			  if (author.equalsIgnoreCase(inventory[i].getAuthor())){
				  System.out.println("Book #" + (i + 1));
				  System.out.println(inventory[i].toString());
				  System.out.println();
				  found =true;
			  }
			  
		  }
		  
		  if(!found){// Will  3check if it respects the conditon for case
			  System.out.println("No books found for the author: " + author);
		    
		  }
		  
		  
		  
		  break;// Exiting the switch
		  
	  // Choice for price 
	  case 4:
		  System.out.print("Please enter a price: ");
		  double price=keyboard.nextDouble();// User will enter his price here
		  
		  
		  found=false;// Decrlaring a variable found type boolean
		  for (int i=0;i<currentBooks;i++) {// Start of for
			  
			  if (inventory[i] != null && inventory[i].getPrice() < price){
				  System.out.println("Book #" + (i + 1));
				  System.out.println(inventory[i].toString());
				  found=true;// will exit the loop when its found
			  }
        }// End of for
		  
		  if (!found) {// Will check if it respects the conditon for case 4
		        System.out.println("No books found under the given price: "+price);
		    }
		  break;// Exiting the switch
		  
	  default:// if user enter an invalid choice 
		  System.out.println("Invalid choice. Try again");
		  
	  
      }// End of switch
	  System.out.println("What do you want to do ?");
	  System.out.println("   1. Enter new books (password required) ");
	  System.out.println("   2. Change information of a book (password required)");
	  System.out.println("   3. Display all books by a specific author ");
	  System.out.println("   4. Display all books under a certain a price.");
	  System.out.println("   5. Quit ");
	  System.out.print("Please enter your choice > ");
	  choice=keyboard.nextInt();
  
   }// End of while 
    keyboard.close();
 }// End of Main
}// End of class
