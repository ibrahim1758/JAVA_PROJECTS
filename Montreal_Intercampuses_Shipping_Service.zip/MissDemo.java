// ---------------------------------------------------------
// Assignment 4 
// Written by: Ibrahim Senhaji 40316859
// For COMP 248 Section H – Fall 2024
// ---------------------------------------------------------

/*This Java program  simulates the registry of any department/facility of 
the six universities of Montreal (Concordia, McGill, UofM, PSofM, ETS, and UQAM) which utilizes for their intercampus shipment: stamps and yearly prepaid 
subscription labels. This new service is called Montreal Intercampus Shipping Service (MISS©) . */


import java.util.Scanner; //Importing a class from java.util that will allow the user after to enter his values
public class MissDemo {// START OF THE DRIVER CALLED MISS DEMO

	public static void main(String[] args) {// START OF MAIN
		// TODO Auto-generated method stub
		
		// For the input
		  Scanner keyboard=new Scanner(System.in);	
		// Welcome the user
		  System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		  System.out.println("| Welcome to Montreal Intercampuses Shipping Service(MISS©) Application               |");
		  System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		
		// Creating the 5 registries
		  //1. 2 Registry have exactly the same stamps types distribution and the same number of labels.
		  // Create the Stamps object for both registries. They have the same number of stamps.
		   Stamps s1=new Stamps(4,0,0,4,1);
		   Stamps s2=new Stamps(s1);// s2 will take the value of s1
		
		   // Create Label objects for the first registry
		   Label l1=new Label("Standard", 9821564, 25, 12);
		   Label l2 = new Label("Confidential", 98703195, 3, 12);
		   // Creating the first Registry with stamps and label1s
		   Label[] labelsForReg0 = {l1, l2};
	       Registry reg0 = new Registry(s1, labelsForReg0);
	       // Creating second label for the second Registry
	        Label l3 = new Label("Fragile", 98825164, 7, 12);
	        Label l4 = new Label("Standard", 98596387, 24, 8);
	        Label[] labelsForReg1 = {new Label(l3), new Label(l4)}; // Using Label copy constructor
	        Registry reg1 = new Registry(s2, labelsForReg1);
	        
	        /* 2. 1 Registry with the same total $ amount of stamps of another Registry but with a different  configuration of stamps types and 
	            at least 3 labels.*/
	        
	        // Stamps configuration for Registry #2
	        Stamps s3 = new Stamps(9, 4, 0, 2, 1);
	        // Labels for Registry #2
	        Label lab1 = new Label("Express", 98432806, 1, 6);  // Express label
	        Label lab2 = new Label("Small", 98087913, 18, 12);  // Small label
	        Label lab3 = new Label("Oversize", 98735421, 5, 4); // Oversize label
	        // Create an array of labels
	        Label[] labelsForReg2 = {lab1, lab2, lab3};
            // Create Registry #2
	        Registry reg2 = new Registry(s3, labelsForReg2);
	        
	        //3. 2 Registries that have the same breakdown of stamps but different from the other 3 with no labels.  
	        
	          // Stamps configuration for the last 2 Registries (different from the first 3)
	             Stamps s4 = new Stamps(3,2,4,1,0);
	             Stamps s5= new Stamps(s4);
	          // Creating Registry #3 with no labels
	             Registry reg3 = new Registry(s4, null);
	          // Creating Registry #4 with same breakdown of stamps, and with no labels
	             Stamps stampsForReg4 = new Stamps(s5); // Use copy constructor
	             Registry reg4 = new Registry(stampsForReg4, null);
	             
	          // Store all registries in an array for easy access
	             Registry[] registries = {reg0, reg1, reg2, reg3, reg4};
	   
		// Display the menu for the user so he can choice what option he wants to use.
	    System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		System.out.println("| What would you like to do ?                                                         |");
		System.out.println("| 1  >> See the content of all Registries                                             |");
		System.out.println("| 2  >> See the content of one Registry                                               |");
		System.out.println("| 3  >> List Registries with same $ amount of shipment Stamps                         |");
		System.out.println("| 4  >> List Registries with same number of shipment Stamps types                     |");
		System.out.println("| 5  >> List Registries with same $ amount of Stamps and same number of prepaid Labels|");
		System.out.println("| 6  >> Add a prepaid label to an existing Registry                                   |");
		System.out.println("| 7  >> Remove an existing prepaid label from a Registry                              |");
		System.out.println("| 8  >> Update the expiry date of an existing prepaid label                           |");
		System.out.println("| 9  >> Add Stamps to a Registry                                                      |");
		System.out.println("| 0  >> To quit                                                                       |");
		System.out.print  ("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		System.out.println();
		System.out.println();
		System.out.print("Please enter your choice and press <Enter>: "); // Here the user will enter his choice.
		int choice=keyboard.nextInt();
		
		while(choice>=0) {// Start of the wile loop. the purpose of this loop is that it will always display the message unless the user chooses to exit.
			
			switch(choice) {// Start of the switch. It's more organized than an if statement. It will contain 9 cases
			case 1:// See the content of each registry
				System.out.println("Content of each Registry:");
	            System.out.println("-------------------------");
	            for (int i = 0; i < registries.length; i++) { // Start of the for loop for the registries.
	                System.out.println("Registry #" + i + ":");
	                System.out.println(registries[i].breakdownStamps());
	                System.out.println(registries[i].toString());
	                System.out.println();
	            }// End of the for loop for registries
	            break;// So it does not go to other cases.
	            
			case 2: //See the content of one Registry  
				System.out.print("Which registry you want to see the content of? (Enter number 0 to 4): ");// The user will enter his value here
				int i = keyboard.nextInt();
				
				//Validation loop to ensure valid input
			    while (i < 0 || i >4) {// Start of while loop
			        System.out.println("Sorry but there is no Registry number " + i);
			        System.out.print("--> Try again: (Enter number 0 to 4): ");
			        i = keyboard.nextInt(); // If the number is not correct the user will try again here.
			    }// End of while loop
				
				 for (int j = 0; j < registries.length; j++) { // Start of the for loop 
				        if (i == j) { // Match the input with the corresponding registry
				            System.out.println(registries[j].breakdownStamps());// Using breakDownStamps method
				            System.out.println(registries[j].toString()); // Using toString method
				            System.out.println();// So it skips a line
				        }// End of if
				        
				    }// End of for the loop
				 break; // So it does not go to other cases
				 
			case 3: //List Registries with same $ amount of shipment stamps. Using the totalAmountStampsMethod.
				System.out.println("List of Registries with same total $ Stamps:");
				System.out.println();

			    // Nested loop to compare registries
			    for (i = 0; i < registries.length; i++) {// Start of the main loop 
			     for (int j = i + 1; j < registries.length; j++) { // Avoid self-comparisons and redundant pairs
			         // Compare the total $ amounts of shipment stamps
			          if (registries[i].totalAmountStamps() == registries[j].totalAmountStamps()) {// Start of if
			             // Display the matching pair and their total $ value
			             System.out.println("        Registries " + i + " and " + j + " both have " 
			             + registries[i].totalAmountStamps());
			            }// End of if
			        }// End of the nested loop 
			    }// End of the main loop 
			    break; // So it does not go to other cases
			    
			case 4 : // Compare all Registries and display the pairs that have the same $ amount distribution.
				System.out.println("List of Registries with same Stamps categories:");
				System.out.println();

			    // Nested loop to compare all registry pairs
			    for (i = 0; i < registries.length; i++) {
			        for (int j = i + 1; j < registries.length; j++) { //Start of the nested loop .(Avoid duplicate pairs)
			            // Access stamps directly from registries and compare using the equals method
			            if (registries[i].equals(registries[j])) {// Start of if
			                // Use the `breakdownStamps` method to display the stamp distribution
			                System.out.println("        Registries " + i + " and " + j + " both have " 
			                                   + registries[i].breakdownStamps());
			            }// End of if
			        }// End of the nested loop 
			    }// End of the main loop 
			    break;
			    
			case 5 :// List all Registries pairs that are equal
				System.out.println("List of Registries with same $ amount of Stamps and same number of Labels:");
			    System.out.println();
			    
               // Loop through all registries to find pairs that are equal
			    for (i = 0; i < registries.length; i++) {
			        for (int j = i + 1; j < registries.length; j++) {// Start of the nested loop. Avoid repetitive pairs
			            if (registries[i].equals(registries[j])) { //Start of if. Use the equals method from Registry class
			                System.out.println("        Registries " + i + " and " + j);
			            }// End of if
			        }// End of the nested loop
			    }// end of the main loop 
			    break;// So it does not go to other cases
			    
			case 6://Ask the user which Registry they want to add a label to
				System.out.print("Which Registry do you want to add an Label to? (Enter number 0 to 4): ");// Ask the user. Will enter his value
			    int registryIndex = keyboard.nextInt();

			    // Validate registry index
			    if (registryIndex < 0 || registryIndex >= registries.length) {// Start of if for validity
			        System.out.println("Invalid Registry number. Please try again.");
			        break;// So it does not go to other cases
			    }// End of if for validity
			    
                // Giving the message to the user
			    System.out.println("Please enter the following information so that we may complete the Label-");

			    // Message for label type
			    System.out.print("--> Type of Label (Confidential, Small, Oversize, Express, Standard, Fragile): ");
			    String labelType = keyboard.next();// He will enter the type here

			    // Message for label ID
			    System.out.print("--> Id of the prepaid label possessor: ");
			    int labelId = keyboard.nextInt();//He will enter the iD here

			    // Message for expiry day and month
			    System.out.print("--> Expiry day number and month (separate by a space): "); // He will enter the day and the month
			    int expiryDay = keyboard.nextInt();
			    int expiryMonth = keyboard.nextInt();

			    // Create a new Label object using the input variables 
			    Label newLabel = new Label(labelType, labelId, expiryDay, expiryMonth);

			    // Access the selected registry
			    Registry selectedRegistry = registries[registryIndex];

			    // Add the new label using the Registry's addNewLabel method
			    selectedRegistry.addNewLabel(newLabel);

			    System.out.println("You have now 1 Label");// Printing the final message of this case
			    break;// So it does not go to other cases
			    
			case 7:// to Remove Label
				System.out.print("Which Registry you want to remove an Label from? (Enter number 0 to " + (registries.length - 1) + "): "); // Ask the user. Will enter his value here
			    registryIndex = keyboard.nextInt();

			    // Validate registry index
			    if (registryIndex < 0 || registryIndex >= registries.length) { // Start of if
			        System.out.println("Invalid Registry number. Please try again.");
			        break; // So it does not go to  other cases
			    }// End of if

			    // Access the selected registry
			    selectedRegistry = registries[registryIndex];

			    // Check if the registry has labels. Using the method numbersOfLabels in the registry class
			    if (selectedRegistry.numbersOfLabels() == 0) {
			        System.out.println("Sorry that Registry has no Labels.");
			        break;
			    }

			    // Prompt for label index
			    System.out.println("(Enter number 0 to " + (selectedRegistry.numbersOfLabels() - 1) + "): ");
			    int labelIndex = keyboard.nextInt();

			    // Validate label index
			    if (labelIndex < 0 || labelIndex >= selectedRegistry.numbersOfLabels()) {
			        System.out.println("Invalid label index. Please try again.");
			        break;
			    }

			    // Remove the label
			    
			    // Creating and assigning boolean variable removed to selectedRegistry.removeLabel(labelIndex).
			    boolean removed = selectedRegistry.removeLabel(labelIndex);
			    if (removed) {
			        System.out.println("Label removed succesfully ");
			    } 
			    
			    else {
			        System.out.println("Failed to remove the label. Please try again.");
			    }
			    break; // So it does not go to other cases
			    
			case 8: // Update registry
				System.out.print("Which Registry do you want to update a Label from? (Enter number 0 to " + (registries.length - 1) + "): ");// The user will enter his value here
			    registryIndex = keyboard.nextInt();

			    // Validate registry index
			    if (registryIndex < 0 || registryIndex >= registries.length) {
			        System.out.println("Invalid Registry number. Please try again."); // Printing the message for consistency
			        break;
			    }
			    
			    selectedRegistry = registries[registryIndex];
			    // Use a method in Registry class to get the number of labels
			    int labelCount = selectedRegistry.numbersOfLabels(); 

			    // Always display label range as (0 to 0).
			    System.out.println("Which Label do you want to update? (Enter number 0 to " + (labelCount == 0 ? 0 : (labelCount - 1)) + "): ");// Will enter the value here
			    labelIndex = keyboard.nextInt();

			    // Even if there are no labels, still proceed to ask for expiry date input
			    System.out.print("--> Enter new expiry date day number and month (separated by a space): ");// Will enter the day and the month here
			    int newDay = keyboard.nextInt();
			    int newMonth = keyboard.nextInt();

			    if (labelCount == 0) {
			        // If no labels exist, output a generic message
			        System.out.println("Expiry Date updated."); // Printing the message for consistency
			        break;
			    }

			    // Validate the label index
			    if (labelIndex < 0 || labelIndex >= labelCount) {
			        System.out.println("Invalid Label number. Please try again.");// Printing the message for consistency
			        break;
			    }

			    // Use a method in Registry class to update the expiry date of the label
			    selectedRegistry.updateLabelExpDate(labelIndex, newDay, newMonth); // Assuming this method exists in Registry

			    System.out.println("Expiry Date updated.");
			    break;
			    
			case 9: // Add registry's stamps
				System.out.print("Which Registry do you want to add Stamps to? (Enter number 0 to " + (registries.length - 1) + "): ");
			    registryIndex = keyboard.nextInt();

			    // Validate the registry index
			    if (registryIndex < 0 || registryIndex >= registries.length) {
			        System.out.println("Invalid Registry number. Please try again.");
			        break;
			    }

			    selectedRegistry = registries[registryIndex];

			    //Ask the user for the number of stamps for each category
			    System.out.println("How many category_A($2), category_B($5), category_C($10), category_D($15) and category_E($20) parcel stamps do you want to add?");
			    System.out.print("Enter 5 numbers separated by a space: "); // He will enter his 5 numbers here
			    // He will have the choice to enter them here
			    int CatA = keyboard.nextInt(); 
			    int CatB = keyboard.nextInt(); 
			    int CatC = keyboard.nextInt(); 
			    int CatD = keyboard.nextInt(); 
			    int CatE = keyboard.nextInt(); 

			    // Create a Stamps object with the input data
			    //Registry additionalStamps = new Registry();
			    // Add these stamps to the selected registry's stamps
			    selectedRegistry.addShipmentsStamps(CatA, CatB, CatC, CatD, CatE);

			    // Display the updated total amount of stamps
			    double totalAmount = (double) selectedRegistry.totalAmountStamps(); // Cast to double to avoid an error message. So it will be like the output example
			    System.out.println("You now have $" + String.format("%.1f", totalAmount));// To round at one decimal
			    break;// So it does not go to other cases
				

			case 0: // If the user wants to exit.
				System.out.print("Thank you for using Montreal Intercampuses Shipping Service(MISS©) Application!");
				return;// So it goes out of the while completely.
				
			default:// If the user selects other options from the options that are displayed.
				System.out.println("Sorry that is not a valid choice. Try again.");
	
			}// End of switch
			System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
			System.out.println("| What would you like to do ?                                                         |");
			System.out.println("| 1  >> See the content of all Registries                                             |");
			System.out.println("| 2  >> See the content of one Registry                                               |");
			System.out.println("| 3  >> List Registries with same $ amount of shipment Stamps                         |");
			System.out.println("| 4  >> List Registries with same number of shipment Stamps types                     |");
			System.out.println("| 5  >> List Registries with same $ amount of Stamps and same number of prepaid Labels|");
			System.out.println("| 6  >> Add a prepaid label to an existing Registry                                   |");
			System.out.println("| 7  >> Remove an existing prepaid label from a Registry                              |");
			System.out.println("| 8  >> Update the expiry date of an existing prepaid label                           |");
			System.out.println("| 9  >> Add Stamps to a Registry                                                      |");
			System.out.println("| 0  >> To quit                                                                       |");
			System.out.print  ("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
			System.out.println();
			System.out.println();
			System.out.print("Please enter your choice and press <Enter>: ");
			choice=keyboard.nextInt();
		
	}// End of while
		keyboard.close();// Closing keyboard
}// End of Main
	
	
}// End of class
