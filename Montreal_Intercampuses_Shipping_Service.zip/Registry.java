// ---------------------------------------------------------
// Assignment 4
// Written by: Ibrahim Senhaji 40316859
// For COMP 248 Section H – Fall 2024
// ---------------------------------------------------------
public class Registry {// START OF CLASS REGISTRY
	
  // Attributes of the class. PRIVATE TYPE to not violate encapsulation.
	private Stamps stamps;// Attribute stamps type class Stamps.
	private Label [] labels;// Attribute labels type Label which will be an array. it will have all the attributes of the class Label
	
  // Constructors
	// Default Constructor. To set all the attributes to their default values.
	  public Registry() {}
	
	//Constructor with 2 parameters to set the initial value of each attribute.
	  // Setting the parameter here. using this. to tell the compiler that I am refering to the variables that I declared previously.
	  public Registry(Stamps stamps, Label[] labels) {
		  this.stamps=stamps;
		  this.labels=labels;
	  }
	  
    // Methods
	  // This method returns true if the 2 objects of Registry have the same total amount
	  
	  public boolean totalAreEqual(Registry other) {
		 return stamps.StampsTotal()==other.stamps.StampsTotal();
	  }
	  
	 /*This method returns true if the the number of each stamps category of two Registry objects are equal.
	  As we can see the method equals from Stamps has been implented since the compiler already knows that is from type Stamps
	  */
	  public boolean numberOfStamps (Registry other) {
		  return stamps.equals(other.stamps);
	  }
	  
	  /*This method will return the total $ amount of  shipment stamps of a Registry.
	   By using the object stamps and the method that was created which is StampsTotal() we will be able to get 
	   the toal $ amount. I used this syntax: nameOfObject.nameOfMethod(actualParameters).
	   In this case, the object is stamps ans the methos is StampTotals with no parameters.
	   */
	  
	  public int totalAmountStamps() {
		  return stamps.StampsTotal();
	  }
	  
	  //This method  will return the number of labels in a Registry. 
	  
	  public int numbersOfLabels () {
		  if (this.labels == null) {
		        return 0; // Return 0 if the array of labels is null
		    }
		  return this.labels.length;
	  }
	  
	 // This method will add a new Label to the Registry. It will returns the number of the labels of a Registry after the addition.  
	  
	  public int addNewLabel(Label newLabel) {
		  if (this.labels == null) {
		        // If the array is null, initialize it with one slot
		        this.labels = new Label[1];
		        this.labels[0] = newLabel;
		    } 
		  
		  else {
		        // Create a new array with one more slot
		        Label[] updatedLabels = new Label[this.labels.length + 1]; // New Array
		        
		        // Copy existing labels into the new array
		        for (int i = 0; i < this.labels.length; i++) {
		            updatedLabels[i] = this.labels[i];
		        }
		        
		        // Add the new label at the end of the array
		        updatedLabels[this.labels.length] = newLabel;
		        
		        // Replace the old array with the updated one
		        this.labels = updatedLabels;
		    }
		    
		    // Return the new total number of labels
		    return this.labels.length;
	  }
	  
	  /*This method will remove a label from the Registry. This method returns true if the removal of the label was successful and false if 
	  it was not. So its type will be boolean.*/
	  
	  public boolean removeLabel(int index ) {
		// Handle case where labels array is null
		    if (this.labels == null || index < 0 || index >= this.labels.length) {
		        return false; // return Removal unsuccessful
		    }

		    // Create a new array with one less slot
		    Label[] updatedLabels = new Label[this.labels.length - 1];
		    int newIndex = 0;

		    // Copy all elements except the one at the specified index.
		    for (int i = 0; i < this.labels.length; i++) {
		        if (i != index) {
		            updatedLabels[newIndex] = this.labels[i];
		            newIndex++;
		        }// End of if
		    }// End of for

		    // Replace the old labels array with the updated one
		    this.labels = updatedLabels;

		    return true; // Removal successful
	  }
	  
	  /*This method will update the expiry day and month of a label. 
	   I included boolean to enhance the method's usability by providing feedback if the user does not enter good values.
	   */
	  public boolean updateLabelExpDate(int index, int otherDay,int otherMonth) {
		// Check if the labels array is null or the index is out of bounds
		    if (this.labels == null || index < 0 || index >= this.labels.length) {
		        return false; // Update unsuccessful
		    }

		    // Validate the new day and month
		    if (otherDay < 1 || otherDay > 31 || otherMonth < 1 || otherMonth > 12) {
		        return false; // Invalid expiry date values
		    }

		    // Update the expiry date of the label at the specified index
		    this.labels[index].setDay(otherDay); // I brought the mutator from Label Class
		    this.labels[index].setMonth(otherMonth);// I brought the mutator again from Label class

		    return true; // Update successful
	  }
	  
	  /*This method will add shipment stamps to the Registry. This method should have 5 
	   parameters, one for each stamp category and returns the new total  shipment stamps value 
       of the Registry.  
	   */
	  
	  public int addShipmentsStamps(int CatA, int CatB,int CatC,int CatD,int CatE) {
		// Add the specified number of stamps to each category in the Stamps object
		  this.stamps.addStamps(CatA, CatB, CatC, CatD, CatE);// Method brought from class Stamps
		// Return the updated total dollar value of the stamps in the registry
		    return this.stamps.StampsTotal();// Method brought from class Stamps
	  }
	  
	  /*This method will return true if the total $ amount of shipment stamps value 
	   and the number of labels of two Registry objects are equal, and false otherwise.  
	   By declaring an object other it will allow me to comparate the two objects from registry.
	   */
	  public boolean equals(Registry other) {
		  return this.stamps.StampsTotal() == other.stamps.StampsTotal() && 
	        ((this.labels == null && other.labels == null) || 
	          (this.labels != null && other.labels != null && this.labels.length == other.labels.length));
	  }
	 
	  
	 /*This method  will return a string clearly indicating the number of each shipment 
       stamp category as well as the details of each prepaid label of the Registry. It is possible for a 
       Registry to have no prepaid shipment label, in which case “No prepaid labels” should be indicated.
	  */
	  public String toString() {
		  if (this.labels == null || this.labels.length == 0) {
		        return "No labels ";
		    }// End of if
		  
		  else {
			    String result = "";
		        for (int i = 0; i < this.labels.length; i++) {
		          result += this.labels[i].toString()+ "\n"; // Append each label
		        }// End of fort
		        return result.trim();// Return the final accumulated string
		    }// End of else
		
	      }
	  
	  public String breakdownStamps() {
		  if (this.stamps == null) {
		      return "No stamps in the registry.";
		    }
		  
		    return this.stamps.toString(); // toString from Stamps
	  }
	  }

