// ---------------------------------------------------------
// Assignment 4
// Written by: Ibrahim Senhaji 40316859
// For COMP 248 Section H – Fall 2024
// ---------------------------------------------------------
public class Stamps { // START OF CLASS STAMPS
// Declaring constants, PRIVATE TYPE to not violate encapsulation.
	private static final int CATEGORIE_A=2;
	private static final int CATEGORIE_B=5;
	private static final int CATEGORIE_C=10;
	private static final int CATEGORIE_D=15;
	private static final int CATEGORIE_E=20;
	
// Private Attributes also to not violate encapsulation. I can use them after because I can't use the constants
	private int CatA;
	private int CatB;
	private int CatC;
	private int CatD;
	private int CatE;
	
	
// Constructors
	// Default Constructor.
	  public Stamps() {}
    
    // Constructor with 5 integer parameters to set the number of each stamp category in the registry. 
	  public Stamps(int a, int b, int c, int d, int e) {// Start of the method Constructor 
		 // Setting the parameter here. using this. to tell the compiler that I am refering to the variables that I declared previously.
		 this.CatA=a;
		 this.CatB=b;
		 this.CatC=c;
		 this.CatD=d;
		 this.CatE=e;
	 }// End of the method Constructor
	  
	 // Copy Constructor with one parameter Stamps
	   /*It duplicates the values of the fields from one object to another, creating a separate,
        independent object with the same state as the original. Basically it creates a nwe object with the same state as the original one
	    */
	   public Stamps (Stamps other) {// Start of Copy constructor
		  this.CatA=other.CatA;
		  this.CatB=other.CatB;
		  this.CatC=other.CatC;
		  this.CatD=other.CatD;
		  this.CatE=other.CatE;
	   }// End of copy constructor
	   
// Accesors
	   // Since the attributes are private we must use getters. They are methods that let you access the values of private attributes in a class.
	   
	   // Getter for Category A
	   public int getA() {
		   return CatA;
	   }
	   
	   // Getter for Category B
	   public int getB() {
		   return CatB;
	   }
	   
	   // Getter for Category C
	   public int getC() {
		   return CatC;
	   }
	   
	// Getter for Category D
	   public int getD() {
		   return CatD;
	   }
	   
	// Getter for Category E
	   public int getE() {
		   return CatE;
	   }
// Mutators 
	   // Setters are methods that allow you to change the values of private attributes in a class. I have the total control of them.
	   
	   // Setter for Category A
	   public void SetA(int CatA) {
		   this.CatA=CatA;
	   }
	   
	   // Setter for Category A
	   public void SetB(int CatB) {
		   this.CatB=CatB;
	   }
	   
	   // Setter for Category A
	   public void SetC(int CatC) {
		   this.CatC=CatC;
	   }
	   
	   // Setter for Category A
	   public void SetD(int CatD) {
		   this.CatD=CatD;
	   }
	   
	   // Setter for Category A
	   public void SetE(int CatE) {
		   this.CatE=CatE;
	   }
	  
// AddStamps() Method
	   public void addStamps(int a,int b,int c,int d,int e) {// Start of addStamps
		   // Increase the number of each parcel stamp category by the indicated number.  
		   this.CatA=CatA+a;
		   this.CatB=CatB+b;
		   this.CatC=CatC+c;
		   this.CatD=CatD+d;
		   this.CatE=CatE+e;
	   }// End of addStamps
	   
// Stamps total () Method. It will sum the numbers of each category. Example: 2 stamps of 2$(First statement).   
	   public int StampsTotal() {// Start of StampsTotal
		   return  (CatA * CATEGORIE_A) +
		           (CatB * CATEGORIE_B) +
		           (CatC * CATEGORIE_C) +
		           (CatD * CATEGORIE_D) +
		           (CatE * CATEGORIE_E);
	   }// End of StampsTotal
	   
// to String() Method
	   public String toString() {// Start of toString
		   return CatA+" x "+"$"+CATEGORIE_A+" + "+ CatB+" x "+"$"+CATEGORIE_B+" + "+CatC+" x "+"$"+CATEGORIE_C+" + "+CatD+" x "+"$"
	              +CATEGORIE_D+" + "+CatE+" x "+"$"+CATEGORIE_E;
	   }// End of toString
// Equals () Method
	   
	   public boolean equals(Stamps other) {// Start of equals
		   return CatA==other.CatA && CatB==other.CatB && CatC==other.CatC && CatD==other.CatD && CatE==other.CatE;
	   }// End of equals
	
} // END OF CLASS STAMPS
