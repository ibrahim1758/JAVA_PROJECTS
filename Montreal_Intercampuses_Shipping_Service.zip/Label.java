// ---------------------------------------------------------
// Assignment 4
// Written by: Ibrahim Senhaji 40316859
// For COMP 248 Section H – Fall 2024
// ---------------------------------------------------------
public class Label {// START OF CLASS LABEL
 // Attributes of the class. PRIVATE TYPE to not violate encapsulation.
	private String type; // Attribute type type String
	private int idOfUnit;// Attribute idOfUnite type int
	private int day;// Attribute day type int
	private int month;// Attribute month type int
	
 // Constructors 
	// Default Constructor. To set all the attributes to their default values.
	public Label() {}
	
	//Constructor with 4 parameters to set the initial value of each attribute.
	public Label(String type, int idOfUnit, int day, int month) {
	   // Setting the parameter here. using this. to tell the compiler that I am refering to the variables that I declared previously.
		this.type=type;
		this.idOfUnit=idOfUnit;
		this.day=day;
		this.month=month;
		// If the day is not between 1 and 31 the day will be set to 0
	if(1<=day&&day>31)
		this.day=0;
	this.month = (month > 0 && month <= 12) ? month : 0; // Default to 0 if invalid
	}
	
	// Copy Constructor
	// Copy Constructor with one parameter type Label
	 /*It duplicates the values of the fields from one object to another, creating a separate,
       independent object with the same state as the original. Basically it creates a new object with the same state as the original one
	    */
	public Label(Label other) {
		this.type=other.type;
		this.idOfUnit=other.idOfUnit;
		this.day=other.day;
		this.month=other.month;
	}
	
	// Accessor methods for all attributes. 
	   // Since the attributes are private we must use getters. They are methods that let you access the values of private attributes in a class.
	
	// Getter for the attribute type
	public String getType() {
		return type;
	}
	// Getter for the attribute IdofUnit
	public int getIdOfUnit() {
		return idOfUnit;
	}
	// Getter for the attribute day
	public int getDay() {
		return idOfUnit;
	}
	// Getter for the month
	public int getMonth() {
		return month;
	}
	
	// Mutator methods for the due date and one for the due month.
	 // Setters are methods that allow you to change the values of private attributes in a class. I have the total control of them.
	
	// Setter for the attribute day
	public void setDay(int day) {
		this.day=day;
		
	    if(1>=day&&day>=31)
			this.day=0;
	}
	// Setter for the attribute month
	public void setMonth(int month) {
		this.month=month;
		
		if (1>=month && month>=12)
			this.month=0;
	}
    // toString() which will return a string indicating the type of the prepaid  label, the due date formatted as dd/mm. 
	public String toString() {// Start of to String
		if (day < 10 && month < 10)
	        return type + " - " + idOfUnit + " - 0" + day + "/0" + month+".";
	    else if (day < 10)
	        return type + " - " + idOfUnit + " - 0" + day + "/" + month+".";
	    else if (month < 10)
	        return type + " - " + idOfUnit + " - " + day + "/0" + month+".";
	    else
	        return type + " - " + idOfUnit + " - " + day + "/" + month+".";
	}// ENd of to String
	
	// Equals() Method
	public boolean equals(Label other) {// Start of equals
		return type==other.type && idOfUnit==other.idOfUnit && day==other.day && month==other.month;
	}// End of equals
	
} //END OF CLASS LABEL
