// ---------------------------------------------------------
// Assignment 2
// Written by: Ibrahim Senhaji 40316859
// For COMP 248 Section H – Fall 2024
// ---------------------------------------------------------

/* This Java program will assist a user in planning a fall outdoor adventure based on temperature and weather conditions. Basically
he will enter the temperature and the weather and based on them the program will print what he should do. ASSUMING THAT THE USER IS PERFECT */

import java.util.Scanner;// Importing a class from java.util that will allow the user after to enter his values
public class A2_Q1 { // Start of class

	public static void main(String[] args) { // Start of main
		// TODO Auto-generated method stub
		
		Scanner keyboard = new Scanner(System.in);// This is for the input
		
		
 //Displaying the fall adventure planner message.
	    System.out.println("###########################################################################");
		System.out.println("                        Fall Adventure Planner!!!         ");
		System.out.println("###########################################################################");
		System.out.println();
		System.out.println("Welcome to the Fall Adventure Planner!");
				

 // Declaring the variable temperature type integer.
	    int temp;
		System.out.print("Enter the current temperature (°C): "); // Here the user will enter the temperature.
		temp=keyboard.nextInt();
		
 // Declaring another variable weather type string.
		String weather;
		System.out.print("Enter the weather condition (sunny/rainy/snowy): "); // Here the user will enter the weather.
		weather=keyboard.next();
		
		System.out.println();
	
		
 // Start of the if-else statements.
		 if (temp>20 && weather.equalsIgnoreCase("sunny")) { // Start of the first if statement.
			System.out.println("Recommended clothing: Light clothing (t-shirt and shorts)."); 
			System.out.println("Safety tip: Don’t forget sunscreen and stay hydrated!");  
		 } // End of the first if statement.
		 
		 else if (weather.equalsIgnoreCase("rainy")) {// Start of the second if statement
		    	System.out.println("Recommended clothing: Waterproof clothing");
		    	System.out.println("Safety tip: Be cautious of slippery paths!");
		    } // End of the second if statement. 
		 
		 else if (temp >= 10 && temp <20) { //  Start of the third if statement
			 System.out.println("Recommended clothing: A light jacket.");
			 if (weather.equalsIgnoreCase("sunny")) { // Start of the first nested if statement
				  System.out.println("Safety tip: Don’t forget sunscreen and stay hydrated!");
				 } // End of the nested if statement
			 
			 if (weather.equalsIgnoreCase("rainy")) { // Start of the second nested if statement
				 System.out.println("Safety tip: Be cautious of slippery paths!");
			    } // End of the second nested if statement
			 
			 if (weather.equalsIgnoreCase("snowy")) { // Start of the third nested if statement
				 System.out.println("Safety tip: Stay warm and watch out for icy conditions!");
			    } // End of the third nested if statement
			 
		 }// End of the third if statement.
		 
	
	    else if (weather.equalsIgnoreCase("snowy")) { // Start of the fifth if statement
	    	System.out.println("Recommended clothing: Heavy winther clothing!");
	    	System.out.println("Safety tip: Stay warm and watch out for icy conditions!");
	    } //End of the fourth if statement.
		 
	    else if (temp<10) {// Start of the fourth if statement
			 System.out.println("Recommended clothing: A sweater and a coat.");
			 
			 if (weather.equalsIgnoreCase("sunny")) { // Start of the first nested if statement
				  System.out.println("Safety tip: Don’t forget sunscreen and stay hydrated!");
				 } // End of the first nested if statement
			 
			 if (weather.equalsIgnoreCase("rainy")) { // Start of the second nested if statement
				 System.out.println("Safety tip: Be cautious of slippery paths!");
			    } // End of the second nested if statement
			 
			 if (weather.equalsIgnoreCase("snowy")) { // Start of the third nested if statement
				 System.out.println("Safety tip: Stay warm and watch out for icy conditions!");
			   } // End of the third nested if statement
			 
		 } // End of fifth if statement.
		 
	 
	// End of the if-else statements.
		 
		System.out.println("Thank you for using the Fall Adventure Planner!"); // Displaying the end message
			
	keyboard.close(); // End of the keyboard.
  }// End of main
 }//End of class
	
