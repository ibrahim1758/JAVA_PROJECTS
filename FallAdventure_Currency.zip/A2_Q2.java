// ---------------------------------------------------------
// Assignment 2
// Written by: Ibrahim Senhaji 40316859
// For COMP 248 Section H – Fall 2024
// ---------------------------------------------------------

/* This Java program simulate operations of a currency exchange shop. The program guide users through 
the process of either buying CAD with their foreign currency or selling CAD for another currency depending on what he wants 
and on what he needs. ASSUMING THAT THE USER IS PERFECT
 */

import java.util.Scanner; // Importing a class from java.util that will allow the user after to enter his values
public class A2_Q2 { // Start of class

	public static void main(String[] args) { //Start of main
		// TODO Auto-generated method stub
		
//Declaring the constants for the problem
	 final double BuyRateUSD= 1.30; final double SaleRateUSD= 1.25;
	 final double BuyRateEUR=1.55;  final double SaleRateEUR=1.50;
	 final double BuyRateGBP= 1.80; final double SaleRateGBP=1.75;
	 final double BuyRateJPY=0.012; final double SaleRateJPY=0.01;
	 final double BuyRateAUD=1.00;  final double SaleRateAUD=0.95;
				
				
 // Displaying the welcome message
		System.out.println("****************************************************************************************");
		System.out.println("                        Montreal Currency Exchange Shop!");
		System.out.println("****************************************************************************************");
		System.out.println();
		System.out.println("Welcome to the Montreal Currency Exchange Shop!");
		
// For the user input
		Scanner keyboard= new Scanner(System.in); // // This will allow the user after to input his values, without this statement he will not be able to do so.
		String buyOrsale; // Declaring the variable buyOrsale type string
		System.out.print("Do you want to buy foreign currency (B) or sell foreign currency (S)? ");// The user will enter here wether he wants to sell his currency or buy his currency
		buyOrsale=keyboard.next(); 
		
// Start of the switch statements.
		
		switch(buyOrsale.toLowerCase()) { // Start of the forst switch statement
		case "b": // If the user wants to buy currency
			String currency; // Declaring a variable currency type string
			System.out.print("Enter the currency you want to buy (USD, EUR, GBP, JPY, AUD): "); // The user will enter here the currency he wants to buy
			currency=keyboard.next();
			
		    double BuyAmount;// Declaring a variable BuyAmount type double
			System.out.print("Enter the amount of "+ currency.toUpperCase() + " you want to buy: "); // The user will enter the amount of the currency he wants to buy
			BuyAmount=keyboard.nextDouble();
			
			
			double rate=0; // Initializing the variable rate
		    switch(currency.toUpperCase()) {// Start of the nested switch statement
			
		    case "USD": // If the user wants to buy usd
		    	rate= SaleRateUSD;
		    	break;
		    case "EUR": // If the user wants to buy eur
		         rate=SaleRateEUR;
		         break;
		    case "GBP": // If the user wants to buy gbp
		         rate=SaleRateGBP;
		         break;
		    case "JPY": // If the user wants to buy jpy
		         rate=SaleRateJPY;
		         break;
		    case "AUD": // If the user wants to buy aud
		         rate=SaleRateAUD;
		         break;
		         } // End of the nested switch statement
		    
		    System.out.println("You need to spend " + String.format("%.2f", BuyAmount*rate) + " CAD to receive "+ String.format("%.2f", BuyAmount)+" " + currency.toUpperCase());
		       //Prinitng out the message for the user depending on what he has inputed following the previous messages  
		       System.out.println("Thank you for visiting!"); // Displaying end message
		    } // End of the first switch statement
		
		switch(buyOrsale.toLowerCase()) { // Start of the second switch statement
		    case "s": // If the user wants to sell currency
			  double SaleAmount; // Declaring the variable SaleAmount type double
			  System.out.print("Enter the CAD amount you would like to receive: "); // Here the user will enter the amount he would like to receive
			  SaleAmount=keyboard.nextDouble();
			
			  String currency; // Declaring a variable currency type string
			  System.out.print("Enter the target currency to sell (USD, EUR, GBP, JPY, AUD): "); // Here the user will enter the currency he wants to sell
			  currency=keyboard.next();
			  
			  double rate=0; // initializing the variable rate
			    switch(currency.toUpperCase()) { // Start of the nested switch statement
				
			    case "USD": // If the user wants to sell usd
			    	rate= BuyRateUSD;
			    	break;
			    case "EUR": // If the user wants to sell eur
			         rate=BuyRateEUR;
			         break;
			    case "GBP": // If the user wants to sell gbp
			         rate=BuyRateGBP;
			         break;
			    case "JPY": // If the user wants to sell jpy
			         rate=BuyRateJPY;
			         break;
			    case "AUD": // If the user wants to sell aud
			         rate=BuyRateAUD;
			         break;
			        } // End of the nested switch statement
			    System.out.println("You need to spend " + String.format("%.2f", (SaleAmount / rate)) + " " + currency.toUpperCase() + " to receive " + String.format("%.2f", SaleAmount) + " CAD");
			       System.out.println("Thank you for visiting!"); // Displaying the end message
			    }
		keyboard.close(); // Closing keyboard
	}// End of Main
} // End of class
